# Validación · Pijama Camisera de Satén (MP26-06-LEN04)

| Control | XS | S | M | L | XL | XXL |
|---|---|---|---|---|---|---|
| Unión delantero = canesú (franja de hombro) | ✓ 0.0 | ✓ 0.0 | ✓ -0.0 | ✓ -0.0 | ✓ 0.0 | ✓ 0.0 |
| Espalda (menos pliegue) = canesú | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Costado delantero (menos pinza) = costado espalda | ✓ -0.0 | ✓ 0.0 | ✓ -0.0 | ✓ -0.0 | ✓ 0.0 | ✓ -0.0 |
| Embebido de copa (copa menos sisa), 0,3 a 1,0 | ✓ 0.7 | ✓ 0.7 | ✓ 0.7 | ✓ 0.7 | ✓ 0.7 | ✓ 0.7 |
| Bajo manga delantero = trasero | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Ruedo de manga con dobladillo de 3,0 cm en espejo | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Pie de cuello (centro esp. a centro del.) = escote | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Cuello = borde superior del pie | ✓ 0.0 | ✓ 0.0 | ✓ -0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Ruedo de manga corta menos contorno de brazo (mín. 6) | ✓ 8.62 | ✓ 7.88 | ✓ 7.32 | ✓ 6.93 | ✓ 6.91 | ✓ 6.93 |
| Holgura de cadera de la camisa (mín. 6) | ✓ 15.0 | ✓ 15.0 | ✓ 15.0 | ✓ 15.0 | ✓ 15.0 | ✓ 15.0 |
| Short: Costado delantero = costado trasero | ✓ -0.0 | ✓ 0.0 | ✓ -0.0 | ✓ -0.0 | ✓ 0.0 | ✓ 0.0 |
| Short: Entrepierna delantera = trasera | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ -0.0 | ✓ -0.0 | ✓ 0.0 |
| Short: Pretina = cintura del pantalón (delantero + trasero) | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Short: Paso de cadera: cintura de la prenda menos cadera (mín. 2) | ✓ 4.26 | ✓ 4.24 | ✓ 4.23 | ✓ 4.21 | ✓ 4.2 | ✓ 4.18 |
| Short: Elástico respecto a la cintura del cuerpo (88 a 95 %) | ✓ 92.03 | ✓ 92.0 | ✓ 91.97 | ✓ 91.95 | ✓ 92.0 | ✓ 92.04 |
| Short: Fruncido de la pretina sobre el elástico (1,2 a 1,7 veces) | ✓ 1.6 | ✓ 1.56 | ✓ 1.52 | ✓ 1.49 | ✓ 1.45 | ✓ 1.42 |
| Short: Holgura de cadera (mín, 9,9) | ✓ 10.0 | ✓ 10.0 | ✓ 10.0 | ✓ 10.0 | ✓ 10.0 | ✓ 10.0 |
| Short: Ruedo con dobladillo de 3,0 cm en espejo | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Contorno válido: Delantero con cartera incorporada | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Espalda con pliegue de holgura | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Canesú doble | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Manga corta | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Pie de cuello (tirilla anatómica) | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Cuello con puntas | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Short · delantero | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Short · trasero | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Pretina con túnel para elástico | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |

## Hojas por talla

| Talla | Carta | A4 |
|---|---|---|
| XS | 25 | 24 |
| S | 27 | 27 |
| M | 29 | 28 |
| L | 32 | 28 |
| XL | 33 | 31 |
| XXL | 35 | 33 |
