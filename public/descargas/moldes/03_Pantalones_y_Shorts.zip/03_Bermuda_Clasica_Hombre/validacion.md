# Validación · Bermuda Clásica Formal (Hombre) (MP26-03-PAN04)

| Control | XS | S | M | L | XL | XXL |
|---|---|---|---|---|---|---|
| Costado delantero (con costadillo) = costado trasero | ✓ 0.0 | ✓ -0.0 | ✓ -0.0 | ✓ 0.0 | ✓ -0.0 | ✓ -0.0 |
| Entrepierna delantera = trasera | ✓ -0.0 | ✓ -0.0 | ✓ 0.0 | ✓ 0.0 | ✓ -0.0 | ✓ 0.0 |
| Boca de bolsillo cabe la mano (mín. 14) | ✓ 3.96 | ✓ 3.97 | ✓ 3.98 | ✓ 3.99 | ✓ 4.12 | ✓ 4.03 |
| Pretina = cintura del pantalón + cruce | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Cintura delantera montada (costadillo + delantero − pinza) = trazado | ✓ 0.01 | ✓ 0.01 | ✓ 0.01 | ✓ 0.01 | ✓ 0.01 | ✓ 0.0 |
| Cintura trasera (menos pinzas) = trazado | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Holgura sobre la línea de cintura de la prenda (1,5 a 2,5) | ✓ 2.01 | ✓ 2.01 | ✓ 2.01 | ✓ 2.01 | ✓ 2.01 | ✓ 2.01 |
| Holgura de cadera (mín, 5,9) | ✓ 6.0 | ✓ 6.0 | ✓ 6.0 | ✓ 6.0 | ✓ 6.0 | ✓ 6.0 |
| Cruce de cremallera (margen de bragueta) | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Aletilla más larga que la cremallera (mín. 1,5) | ✓ 2.0 | ✓ 2.0 | ✓ 2.0 | ✓ 2.0 | ✓ 2.0 | ✓ 2.0 |
| Ruedo con dobladillo de 3,0 cm | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Contorno válido: Delantero con bragueta | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Trasero con bolsillo ribeteado | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Costadillo de bolsillo | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Fondo de bolsillo (forro) | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Aletilla (vista de bragueta) | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Pie de bragueta (bajo cremallera) | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Ribete de bolsillo trasero | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Espejo de bolsillo trasero | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Fondo de bolsillo trasero (forro) | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Pretina sastre | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Tira de pasadores (7 de 9 cm) | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |

## Hojas por talla

| Talla | Carta | A4 |
|---|---|---|
| XS | 24 | 21 |
| S | 24 | 21 |
| M | 25 | 23 |
| L | 28 | 27 |
| XL | 29 | 28 |
| XXL | 31 | 29 |
