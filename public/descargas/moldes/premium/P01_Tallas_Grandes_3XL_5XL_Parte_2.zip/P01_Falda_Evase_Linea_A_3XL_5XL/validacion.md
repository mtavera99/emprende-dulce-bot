# Validación · Falda Evasé Línea A con Vuelo · Tallas grandes (MP26-04-FAL02-G)

| Control | 3XL | 4XL | 5XL |
|---|---|---|---|
| Costado delantero = costado trasero | ✓ -0.01 | ✓ -0.01 | ✓ -0.01 |
| Cintura delantera (pinza cerrada) = trazado | ✓ 0.06 | ✓ 0.07 | ✓ 0.07 |
| Cintura trasera (pinza cerrada) = trazado | ✓ 0.04 | ✓ 0.04 | ✓ 0.04 |
| Pretina delantera = cintura delantera | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 |
| Pretina trasera = cintura trasera | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 |
| Holgura de cadera (mín. 4) | ✓ 23.91 | ✓ 24.79 | ✓ 25.66 |
| Vuelo: ruedo menos cadera de la prenda (mín. 25) | ✓ 45.53 | ✓ 45.22 | ✓ 44.91 |
| Margen de cremallera invisible | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Ruedo con dobladillo de 3,0 cm en espejo | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Contorno válido: Delantero evasé | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Trasero evasé | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Pretina delantera | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Pretina trasera | ✓ 0 | ✓ 0 | ✓ 0 |

## Hojas por talla

| Talla | Carta | A4 |
|---|---|---|
| 3XL | 20 | 18 |
| 4XL | 22 | 22 |
| 5XL | 22 | 22 |
