# Validación · Scrub Médico: Filipina Cuello V + Jogger (MP26-10-UNI01)

| Control | XS | S | M | L | XL | XXL |
|---|---|---|---|---|---|---|
| Hombro delantero = hombro espalda | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Costado delantero = costado espalda | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Embebido de copa (copa menos sisa), 0,3 a 1,0 | ✓ 0.6 | ✓ 0.6 | ✓ 0.6 | ✓ 0.6 | ✓ 0.6 | ✓ 0.6 |
| Bajo manga delantero = trasero | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Vista delantera: escote = escote en V | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Vista de espalda: escote = escote de espalda | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Vista: hombro delantero = hombro de espalda | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Holgura de pecho (14 a 18) | ✓ 16.0 | ✓ 16.0 | ✓ 16.0 | ✓ 16.0 | ✓ 16.0 | ✓ 16.0 |
| Paso de cabeza sin abertura: escote menos cabeza (mín. 0) | ✓ 5.16 | ✓ 5.76 | ✓ 6.35 | ✓ 7.51 | ✓ 8.68 | ✓ 9.84 |
| Abertura lateral: margen de 1,5 cm | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Ruedo con dobladillo de 3,0 cm en espejo | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Jogger: Costado delantero (con costadillo) = costado trasero | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 | ✓ 0.0 | ✓ 0.0 |
| Jogger: Entrepierna delantera = trasera | ✓ 0.0 | ✓ 0.0 | ✓ -0.0 | ✓ 0.0 | ✓ 0.0 | ✓ -0.0 |
| Jogger: Boca de bolsillo cabe la mano (mín. 14) | ✓ 3.49 | ✓ 3.49 | ✓ 3.5 | ✓ 3.5 | ✓ 3.51 | ✓ 3.51 |
| Jogger: Pretina = cintura del pantalón (delantero + trasero) | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Jogger: Paso de cadera: cintura de la prenda menos cadera (mín. 2) | ✓ 3.3 | ✓ 3.28 | ✓ 3.27 | ✓ 3.26 | ✓ 3.26 | ✓ 3.25 |
| Jogger: Elástico respecto a la cintura del cuerpo (88 a 95 %) | ✓ 91.94 | ✓ 92.05 | ✓ 92.02 | ✓ 92.0 | ✓ 92.04 | ✓ 91.98 |
| Jogger: Fruncido de la pretina sobre el elástico (1,2 a 1,7 veces) | ✓ 1.38 | ✓ 1.35 | ✓ 1.34 | ✓ 1.32 | ✓ 1.28 | ✓ 1.24 |
| Jogger: Holgura de cadera (mín, 9,9) | ✓ 10.0 | ✓ 10.0 | ✓ 10.0 | ✓ 10.0 | ✓ 10.0 | ✓ 10.0 |
| Jogger: Puño de tobillo = 75 % de la abertura de la pierna | ✓ -0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ -0.0 |
| Jogger: Paso de talón: puño estirado al 160 % menos (tobillo + 10) (mín. 0) | ✓ 5.08 | ✓ 5.84 | ✓ 6.6 | ✓ 7.36 | ✓ 8.12 | ✓ 8.98 |
| Contorno válido: Filipina · delantero | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Filipina · espalda | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Vista de escote delantera | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Vista de escote espalda | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Filipina · manga corta | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Bolsillo de pecho | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Bolsillo inferior con división | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Jogger · delantero | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Jogger · trasero | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Costadillo de bolsillo | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Fondo de bolsillo (forro) | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Pretina con túnel para elástico y cordón | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Puño de tobillo en rib | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |

## Hojas por talla

| Talla | Carta | A4 |
|---|---|---|
| XS | 37 | 38 |
| S | 41 | 43 |
| M | 46 | 44 |
| L | 46 | 46 |
| XL | 51 | 46 |
| XXL | 53 | 47 |
