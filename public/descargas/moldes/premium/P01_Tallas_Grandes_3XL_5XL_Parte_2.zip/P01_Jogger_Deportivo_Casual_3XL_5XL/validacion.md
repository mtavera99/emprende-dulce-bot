# Validación · Jogger Deportivo Casual · Tallas grandes (MP26-05-DEP03-G)

| Control | 3XL | 4XL | 5XL |
|---|---|---|---|
| Costado delantero (con costadillo) = costado trasero | ✓ 0.0 | ✓ 0.0 | ✓ -0.0 |
| Entrepierna delantera = trasera | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Boca de bolsillo cabe la mano (mín. 14) | ✓ 2.56 | ✓ 2.56 | ✓ 2.56 |
| Pretina = cintura del pantalón (delantero + trasero) | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Paso de cadera: cintura de la prenda menos cadera (mín. 2) | ✓ 4.25 | ✓ 4.25 | ✓ 4.25 |
| Elástico respecto a la cintura del cuerpo (88 a 95 %) | ✓ 91.98 | ✓ 92.02 | ✓ 91.97 |
| Fruncido de la pretina sobre el elástico (1,2 a 1,7 veces) | ✓ 1.4 | ✓ 1.38 | ✓ 1.36 |
| Holgura de cadera (mín, 9,9) | ✓ 10.0 | ✓ 10.0 | ✓ 10.0 |
| Puño de tobillo = 75 % de la abertura de la pierna | ✓ -0.0 | ✓ 0.0 | ✓ 0.0 |
| Paso de talón: puño estirado al 160 % menos (tobillo + 10) (mín. 0) | ✓ 14.92 | ✓ 16.7 | ✓ 18.48 |
| Contorno válido: Delantero con bolsillo inclinado | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Trasero | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Costadillo de bolsillo | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Fondo de bolsillo (forro) | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Pretina con túnel para elástico y cordón | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Puño de tobillo en rib | ✓ 0 | ✓ 0 | ✓ 0 |

## Hojas por talla

| Talla | Carta | A4 |
|---|---|---|
| 3XL | 31 | 30 |
| 4XL | 32 | 32 |
| 5XL | 33 | 34 |
