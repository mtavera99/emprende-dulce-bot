# Validación · Pijama Camisera de Satén · Tallas grandes (MP26-06-LEN04-G)

| Control | 3XL | 4XL | 5XL |
|---|---|---|---|
| Unión delantero = canesú (franja de hombro) | ✓ 0.0 | ✓ 0.0 | ✓ -0.0 |
| Espalda (menos pliegue) = canesú | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Costado delantero (menos pinza) = costado espalda | ✓ 0.0 | ✓ 0.0 | ✓ -0.0 |
| Embebido de copa (copa menos sisa), 0,3 a 1,0 | ✓ 0.7 | ✓ 0.7 | ✓ 0.7 |
| Bajo manga delantero = trasero | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Ruedo de manga con dobladillo de 3,0 cm en espejo | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Pie de cuello (centro esp. a centro del.) = escote | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Cuello = borde superior del pie | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Ruedo de manga corta menos contorno de brazo (mín. 6) | ✓ 6.96 | ✓ 7.02 | ✓ 7.09 |
| Holgura de cadera de la camisa (mín. 6) | ✓ 15.0 | ✓ 15.0 | ✓ 15.0 |
| Short: Costado delantero = costado trasero | ✓ -0.0 | ✓ -0.0 | ✓ 0.0 |
| Short: Entrepierna delantera = trasera | ✓ -0.0 | ✓ 0.0 | ✓ -0.0 |
| Short: Pretina = cintura del pantalón (delantero + trasero) | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Short: Paso de cadera: cintura de la prenda menos cadera (mín. 2) | ✓ 4.17 | ✓ 4.16 | ✓ 4.15 |
| Short: Elástico respecto a la cintura del cuerpo (88 a 95 %) | ✓ 91.98 | ✓ 92.02 | ✓ 91.97 |
| Short: Fruncido de la pretina sobre el elástico (1,2 a 1,7 veces) | ✓ 1.4 | ✓ 1.37 | ✓ 1.36 |
| Short: Holgura de cadera (mín, 9,9) | ✓ 10.0 | ✓ 10.0 | ✓ 10.0 |
| Short: Ruedo con dobladillo de 3,0 cm en espejo | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Contorno válido: Delantero con cartera incorporada | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Espalda con pliegue de holgura | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Canesú doble | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Manga corta | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Pie de cuello (tirilla anatómica) | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Cuello con puntas | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Short · delantero | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Short · trasero | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Pretina con túnel para elástico | ✓ 0 | ✓ 0 | ✓ 0 |

## Hojas por talla

| Talla | Carta | A4 |
|---|---|---|
| 3XL | 36 | 35 |
| 4XL | 38 | 38 |
| 5XL | 38 | 40 |
