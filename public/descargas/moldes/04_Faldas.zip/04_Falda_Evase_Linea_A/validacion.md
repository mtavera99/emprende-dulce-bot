# Validación · Falda Evasé Línea A con Vuelo (MP26-04-FAL02)

| Control | XS | S | M | L | XL | XXL |
|---|---|---|---|---|---|---|
| Costado delantero = costado trasero | ✓ -0.01 | ✓ -0.01 | ✓ -0.01 | ✓ -0.01 | ✓ -0.01 | ✓ -0.01 |
| Cintura delantera (pinza cerrada) = trazado | ✓ 0.04 | ✓ 0.04 | ✓ 0.05 | ✓ 0.05 | ✓ 0.05 | ✓ 0.06 |
| Cintura trasera (pinza cerrada) = trazado | ✓ 0.03 | ✓ 0.03 | ✓ 0.03 | ✓ 0.03 | ✓ 0.03 | ✓ 0.04 |
| Pretina delantera = cintura delantera | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 |
| Pretina trasera = cintura trasera | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 |
| Holgura de cadera (mín. 4) | ✓ 18.83 | ✓ 19.65 | ✓ 20.47 | ✓ 21.29 | ✓ 22.16 | ✓ 23.04 |
| Vuelo: ruedo menos cadera de la prenda (mín. 25) | ✓ 45.3 | ✓ 45.68 | ✓ 46.07 | ✓ 46.46 | ✓ 46.15 | ✓ 45.84 |
| Margen de cremallera invisible | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Ruedo con dobladillo de 3,0 cm en espejo | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Contorno válido: Delantero evasé | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Trasero evasé | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Pretina delantera | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Pretina trasera | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |

## Hojas por talla

| Talla | Carta | A4 |
|---|---|---|
| XS | 15 | 15 |
| S | 15 | 15 |
| M | 17 | 15 |
| L | 18 | 15 |
| XL | 18 | 18 |
| XXL | 18 | 18 |
