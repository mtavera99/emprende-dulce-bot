# Validación · Top Deportivo Racerback (MP26-05-DEP02)

| Control | XS | S | M | L | XL | XXL |
|---|---|---|---|---|---|---|
| Hombro delantero = hombro espalda | ✓ -0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ -0.0 |
| Costado delantero = costado espalda | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Banda = borde inferior (delantero + espalda) | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Forro: borde inferior = delantero + cruce | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Compresión en busto (objetivo −8 %, ±0,5 %) | ✓ -8.0 | ✓ -8.0 | ✓ -8.0 | ✓ -8.0 | ✓ -8.0 | ✓ -8.0 |
| Compresión en bajo busto (objetivo −8 %, ±0,5 %) | ✓ -7.9 | ✓ -7.91 | ✓ -7.92 | ✓ -7.93 | ✓ -7.94 | ✓ -7.95 |
| Elástico de banda respecto al bajo busto (83 a 88 %) | ✓ 85.0 | ✓ 85.07 | ✓ 85.0 | ✓ 84.94 | ✓ 85.0 | ✓ 84.95 |
| Paso por busto y hombros: elástico estirado al 150 % menos busto (mín. 0) | ✓ 7.25 | ✓ 7.7 | ✓ 8.0 | ✓ 8.3 | ✓ 9.3 | ✓ 10.15 |
| Ancho mínimo del tirante delantero (mín. 3,5) | ✓ 4.0 | ✓ 4.24 | ✓ 4.48 | ✓ 4.72 | ✓ 5.04 | ✓ 5.36 |
| Ancho mínimo del tirante de espalda (mín. 3,5) | ✓ 3.96 | ✓ 4.18 | ✓ 4.41 | ✓ 4.64 | ✓ 4.94 | ✓ 5.25 |
| Espalda nadadora: ancho central respecto al ancho de espalda (15 a 30 %, omóplatos libres) | ✓ 22.0 | ✓ 22.0 | ✓ 22.0 | ✓ 22.0 | ✓ 22.0 | ✓ 22.0 |
| Paso de cabeza: escote estirado al 130 % menos cabeza (mín. 0) | ✓ 13.0 | ✓ 15.32 | ✓ 17.68 | ✓ 20.4 | ✓ 23.57 | ✓ 26.77 |
| Abertura de copas (largo del cruce, mín. 12) | ✓ 19.0 | ✓ 19.35 | ✓ 19.7 | ✓ 20.05 | ✓ 20.4 | ✓ 20.75 |
| Contorno válido: Delantero | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Forro delantero con abertura para copas | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Espalda nadadora | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Banda bajo busto (túnel del elástico) | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |

## Hojas por talla

| Talla | Carta | A4 |
|---|---|---|
| XS | 8 | 8 |
| S | 8 | 8 |
| M | 9 | 9 |
| L | 11 | 9 |
| XL | 12 | 10 |
| XXL | 13 | 10 |
