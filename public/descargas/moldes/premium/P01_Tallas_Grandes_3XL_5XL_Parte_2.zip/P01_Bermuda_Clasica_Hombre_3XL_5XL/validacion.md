# Validación · Bermuda Clásica Formal (Hombre) · Tallas grandes (MP26-03-PAN04-G)

| Control | 3XL | 4XL | 5XL |
|---|---|---|---|
| Costado delantero (con costadillo) = costado trasero | ✓ 0.0 | ✓ -0.0 | ✓ 0.0 |
| Entrepierna delantera = trasera | ✓ 0.0 | ✓ -0.0 | ✓ 0.0 |
| Boca de bolsillo cabe la mano (mín. 14) | ✓ 4.04 | ✓ 4.04 | ✓ 4.05 |
| Pretina = cintura del pantalón + cruce | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Cintura delantera montada (costadillo + delantero − pinza) = trazado | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Cintura trasera (menos pinzas) = trazado | ✓ 0.0 | ✓ 0.0 | ✓ -0.0 |
| Holgura sobre la línea de cintura de la prenda (1,5 a 2,5) | ✓ 2.01 | ✓ 2.01 | ✓ 2.01 |
| Holgura de cadera (mín, 5,9) | ✓ 6.0 | ✓ 6.0 | ✓ 6.0 |
| Cruce de cremallera (margen de bragueta) | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Aletilla más larga que la cremallera (mín. 1,5) | ✓ 2.0 | ✓ 2.0 | ✓ 2.0 |
| Ruedo con dobladillo de 3,0 cm | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Contorno válido: Delantero con bragueta | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Trasero con bolsillo ribeteado | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Costadillo de bolsillo | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Fondo de bolsillo (forro) | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Aletilla (vista de bragueta) | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Pie de bragueta (bajo cremallera) | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Ribete de bolsillo trasero | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Espejo de bolsillo trasero | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Fondo de bolsillo trasero (forro) | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Pretina sastre | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Tira de pasadores (7 de 9 cm) | ✓ 0 | ✓ 0 | ✓ 0 |

## Hojas por talla

| Talla | Carta | A4 |
|---|---|---|
| 3XL | 33 | 30 |
| 4XL | 34 | 35 |
| 5XL | 38 | 36 |
