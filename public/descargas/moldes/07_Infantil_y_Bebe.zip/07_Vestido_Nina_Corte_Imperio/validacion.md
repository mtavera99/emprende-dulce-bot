# Validación · Vestido de Niña con Corte Imperio (MP26-07-INF02)

| Control | 2 | 4 | 6 | 8 | 10 |
|---|---|---|---|---|---|
| Hombro delantero = hombro espalda | ✓ 0.0 | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 |
| Costado de corpiño: delantero = espalda | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Costado de falda: delantera = trasera | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Fruncido de falda delantera (1,75 a 1,85) | ✓ 1.8 | ✓ 1.8 | ✓ 1.8 | ✓ 1.8 | ✓ 1.8 |
| Fruncido de falda trasera (1,75 a 1,85) | ✓ 1.8 | ✓ 1.8 | ✓ 1.8 | ✓ 1.8 | ✓ 1.8 |
| Frunce de copa: copa menos sisa (3 a 5) | ✓ 4.0 | ✓ 4.0 | ✓ 4.0 | ✓ 4.0 | ✓ 4.0 |
| Bajo manga delantero = trasero | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Holgura de pecho (7 a 10) | ✓ 8.0 | ✓ 8.0 | ✓ 8.0 | ✓ 8.0 | ✓ 8.0 |
| Margen de cremallera invisible | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Ruedo con dobladillo de 3,0 cm en espejo | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Ancho de manga menos brazo (mín. 7,9) | ✓ 9.41 | ✓ 10.25 | ✓ 10.62 | ✓ 11.13 | ✓ 11.23 |
| Contorno válido: Corpiño delantero | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Corpiño espalda | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Manga corta abullonada | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Falda delantera fruncida | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Falda trasera fruncida | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |

## Hojas por talla

| Talla | Carta | A4 |
|---|---|---|
| 2 | 11 | 11 |
| 4 | 11 | 12 |
| 6 | 15 | 12 |
| 8 | 16 | 16 |
| 10 | 17 | 18 |
