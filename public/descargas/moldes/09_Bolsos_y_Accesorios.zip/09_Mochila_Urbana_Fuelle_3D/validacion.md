# Validación · Mochila Urbana con Fuelle 3D (MP26-09-BOL03)

| Control | Mini | Mediano | Grande |
|---|---|---|---|
| Perímetro del panel = tramo de cremallera + tramo lateral | ✓ 0.0 | ✓ 0.0 | ✓ -0.0 |
| Fuelle superior = tramo de cremallera del panel + 2 cm de cruce | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Fuelle lateral = tramo lateral del panel + 2 cm de cruce | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Extremo de fuelle lateral = 2 fuelles superiores + cremallera | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Fuelle de bolsillo = contorno del bolsillo | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Tapa cubre el bolsillo con su fuelle abierto (mín. 0) | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Margen del bolsillo a los costados del panel (mín. 6) | ✓ 7.8 | ✓ 9.0 | ✓ 9.9 |
| Capacidad (mín. 7 litros) | ✓ 8.5 | ✓ 15.9 | ✓ 22.1 |
| Contorno válido: Panel delantero | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Panel de espalda | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Fuelle superior con cremallera | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Fuelle lateral y base | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Bolsillo frontal 3D | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Fuelle de bolsillo (3D) | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Tapa de bolsillo | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Tirante acolchado | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Asa superior (doblada en 4) | ✓ 0 | ✓ 0 | ✓ 0 |

## Hojas por talla

| Talla | Carta | A4 |
|---|---|---|
| Mini | 16 | 16 |
| Mediano | 22 | 22 |
| Grande | 22 | 23 |
