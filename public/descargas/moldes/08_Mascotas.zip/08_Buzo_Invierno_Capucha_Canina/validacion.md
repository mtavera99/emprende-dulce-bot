# Validación · Buzo de Invierno con Capucha Canina (MP26-08-PER01)

| Control | S | M | L | XL |
|---|---|---|---|---|
| Costado superior: lomo = pechera | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Costado inferior: lomo = pechera | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Escote de capucha = escote lomo + pechera | ✓ 0.0 | ✓ -0.0 | ✓ 0.0 | ✓ 0.0 |
| Sisa (lomo + pechera) = pata + holgura | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Puño de sisa = 85 % de la sisa | ✓ -0.0 | ✓ 0.0 | ✓ -0.0 | ✓ 0.0 |
| Pretina = 85 % del ruedo | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Rib de cara = 90 % de la abertura | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Paso de cabeza: cuello de la prenda menos 95 % de la cabeza (mín. 0) | ✓ 1.4 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Holgura de pecho de la prenda (mín. 4) | ✓ 6.0 | ✓ 7.4 | ✓ 8.8 | ✓ 10.2 |
| Vientre libre (largo de lomo menos largo de vientre, mín. 25 % del lomo) | ✓ 9.24 | ✓ 11.98 | ✓ 17.36 | ✓ 21.92 |
| Coronilla: costura de cráneo menos (largo de cabeza + 6) (mín. 0) | ✓ 6.5 | ✓ 10.55 | ✓ 15.11 | ✓ 19.66 |
| Contorno válido: Lomo dorsal con ranura para arnés | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Pechera ventral (corte higiénico) | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Capucha canina anatómica | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Rib de capucha (vista de cara) | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Puño de sisa | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Pretina (ruedo dorsal + ventral) | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |

## Hojas por talla

| Talla | Carta | A4 |
|---|---|---|
| S | 6 | 6 |
| M | 11 | 11 |
| L | 13 | 13 |
| XL | 21 | 21 |
