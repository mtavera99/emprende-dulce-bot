# Validación · Bustier Escote Corazón 6 Paneles con Cordones (MP26-P04-COR07)

| Control | XS | S | M | L | XL | XXL | 3XL | 4XL | 5XL |
|---|---|---|---|---|---|---|---|---|---|
| Costura 1–2: las dos orillas miden igual | ✓ 0.0 | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ -0.0 |
| Costura 2–3: las dos orillas miden igual | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 |
| Costura 3–4: las dos orillas miden igual | ✓ -0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ -0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Costura 4–5: las dos orillas miden igual | ✓ 0.0 | ✓ 0.0 | ✓ -0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ -0.0 |
| Costura 5–6: las dos orillas miden igual | ✓ -0.0 | ✓ 0.0 | ✓ 0.0 | ✓ -0.0 | ✓ -0.0 | ✓ 0.0 | ✓ -0.0 | ✓ 0.0 | ✓ -0.0 |
| Contorno del corsé en borde superior = objetivo (±0,3 cm) | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ -0.0 | ✓ 0.0 |
| Contorno del corsé en busto = objetivo (±0,3 cm) | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ -0.0 | ✓ 0.0 |
| Contorno del corsé en bajo busto = objetivo (±0,3 cm) | ✓ 0.0 | ✓ 0.0 | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 | ✓ 0.0 | ✓ 0.0 | ✓ -0.0 | ✓ 0.0 |
| Contorno del corsé en cintura = objetivo (±0,3 cm) | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 | ✓ 0.0 | ✓ 0.0 | ✓ -0.0 | ✓ -0.0 | ✓ 0.0 |
| Contorno del corsé en borde inferior = objetivo (±0,3 cm) | ✓ 0.0 | ✓ -0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ -0.0 | ✓ -0.0 | ✓ 0.0 |
| Reducción de cintura frente al cuerpo (cm, con la abertura de espalda) | ✓ 4.0 | ✓ 4.0 | ✓ 4.0 | ✓ 4.0 | ✓ 4.0 | ✓ 4.0 | ✓ 4.0 | ✓ 4.0 | ✓ 4.0 |
| Ancho mínimo de panel en la cintura (mín, 3,5 cm para la varilla y su canal) | ✓ 4.67 | ✓ 5.17 | ✓ 5.67 | ✓ 6.17 | ✓ 6.83 | ✓ 7.5 | ✓ 8.17 | ✓ 8.83 | ✓ 9.5 |
| Varilla más corta (mín. 8 cm) | ✓ 21.53 | ✓ 22.03 | ✓ 22.43 | ✓ 22.53 | ✓ 22.33 | ✓ 21.93 | ✓ 21.43 | ✓ 20.92 | ✓ 20.42 |
| Contorno válido: Panel 1 · Centro delantero | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Panel 2 · Frente | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Panel 3 · Costado delantero | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Panel 4 · Costado trasero | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Panel 5 · Espalda | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Panel 6 · Centro espalda | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Panel de modestia (va bajo los cordones) | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Cinta de cintura (estabiliza la reducción) | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |

## Hojas por talla

| Talla | Carta | A4 |
|---|---|---|
| XS | 8 | 9 |
| S | 9 | 9 |
| M | 9 | 9 |
| L | 9 | 9 |
| XL | 9 | 10 |
| XXL | 11 | 11 |
| 3XL | 11 | 11 |
| 4XL | 11 | 11 |
| 5XL | 12 | 11 |
