# Validación · Bralette de Encaje con Copas Triangulares (MP26-06-LEN01)

| Control | XS | S | M | L | XL | XXL |
|---|---|---|---|---|---|---|
| Costura de copa: central = lateral | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ -0.0 |
| Base de copas cosida (sin pinza) = banda delantera menos puente central | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Costado: banda delantera = banda de espalda | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Compresión bajo busto con corchete en posición central (objetivo −10 %, ±0,5 %) | ✓ -10.0 | ✓ -10.0 | ✓ -10.0 | ✓ -10.0 | ✓ -10.0 | ✓ -10.0 |
| Proyección de copa respecto a (busto − bajo busto) (0,18 a 0,35) | ✓ 0.25 | ✓ 0.27 | ✓ 0.29 | ✓ 0.3 | ✓ 0.31 | ✓ 0.32 |
| Elástico afelpado respecto al borde de la banda (95 a 99 %) | ✓ 96.98 | ✓ 97.04 | ✓ 96.94 | ✓ 96.99 | ✓ 96.98 | ✓ 96.97 |
| Banda de espalda: largo útil (mín. 8) | ✓ 14.25 | ✓ 15.38 | ✓ 16.5 | ✓ 17.62 | ✓ 19.2 | ✓ 20.78 |
| Contorno válido: Copa central | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Copa lateral | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Banda delantera bajo copa | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Banda de espalda | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |

## Hojas por talla

| Talla | Carta | A4 |
|---|---|---|
| XS | 3 | 4 |
| S | 4 | 4 |
| M | 4 | 4 |
| L | 4 | 4 |
| XL | 4 | 4 |
| XXL | 5 | 5 |
