# Validación · Legging Largo con Bolsillo para Celular (MP26-P02-DEP07)

| Control | XS | S | M | L | XL | XXL | 3XL | 4XL | 5XL |
|---|---|---|---|---|---|---|---|---|---|
| Costado delantero = costado trasero | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Entrepierna delantera = trasera (desde el refuerzo) | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ -0.0 | ✓ -0.0 | ✓ 0.0 | ✓ 0.0 | ✓ -0.0 |
| Refuerzo: lado delantero = corte del delantero | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Refuerzo: lado trasero = corte del trasero | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Pretina delantera = cintura delantera | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 |
| Pretina trasera = cintura trasera | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 |
| Compresión en cadera (objetivo −15 %, ±0,5 %) | ✓ -15.0 | ✓ -15.0 | ✓ -15.0 | ✓ -15.0 | ✓ -15.0 | ✓ -15.0 | ✓ -15.0 | ✓ -15.0 | ✓ -15.0 |
| Compresión del ruedo contra el cuerpo a esa altura (-20 % a -3 %) | ✓ -5.0 | ✓ -5.0 | ✓ -5.0 | ✓ -5.0 | ✓ -5.0 | ✓ -5.0 | ✓ -5.0 | ✓ -5.0 | ✓ -5.0 |
| Paso de cadera: estiramiento que necesita la cintura para pasar la cadera (máx. 60 %) | ✓ 58.86 | ✓ 55.76 | ✓ 54.26 | ✓ 51.39 | ✓ 48.2 | ✓ 45.86 | ✓ 43.92 | ✓ 42.23 | ✓ 40.76 |
| Compresión del canto superior de pretina (−5 % a −15 %) | ✓ -11.48 | ✓ -11.95 | ✓ -13.0 | ✓ -13.0 | ✓ -13.03 | ✓ -13.25 | ✓ -13.47 | ✓ -13.66 | ✓ -13.82 |
| Paso del pie por el ruedo estirado al 160 % (mín. 0) | ✓ 0.4 | ✓ 0.66 | ✓ 0.92 | ✓ 1.18 | ✓ 1.7 | ✓ 2.22 | ✓ 2.74 | ✓ 3.26 | ✓ 3.78 |
| Tiro con refuerzo frente a tiro sin refuerzo (−2,0 a 0) | ✓ -1.0 | ✓ -1.0 | ✓ -1.0 | ✓ -1.0 | ✓ -1.0 | ✓ -1.0 | ✓ -1.0 | ✓ -1.0 | ✓ -1.0 |
| Bolsillo: costado = tramo del costado del delantero | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ -0.0 | ✓ 0.0 | ✓ 0.0 | ✓ -0.0 | ✓ 0.0 |
| Bolsillo: ancho para celular (mín. 9 cm) | ✓ 13.0 | ✓ 13.0 | ✓ 13.0 | ✓ 13.0 | ✓ 13.0 | ✓ 13.0 | ✓ 13.0 | ✓ 13.0 | ✓ 13.0 |
| Bolsillo: queda por encima del ruedo (mín. 3 cm) | ✓ 71.0 | ✓ 72.0 | ✓ 73.0 | ✓ 74.0 | ✓ 74.5 | ✓ 75.0 | ✓ 75.5 | ✓ 76.0 | ✓ 76.5 |
| Contorno válido: Delantero | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Trasero | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Refuerzo anatómico en rombo (gusset) | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Bolsillo lateral para celular | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Pretina delantera de compresión | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Pretina trasera de compresión | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |

## Hojas por talla

| Talla | Carta | A4 |
|---|---|---|
| XS | 16 | 16 |
| S | 16 | 16 |
| M | 16 | 19 |
| L | 20 | 20 |
| XL | 20 | 20 |
| XXL | 20 | 20 |
| 3XL | 21 | 21 |
| 4XL | 21 | 20 |
| 5XL | 22 | 22 |
