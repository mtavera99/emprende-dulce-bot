# Validación · Corsé Underbust 8 Paneles Costillar Alto (MP26-P04-COR06)

| Control | XS | S | M | L | XL | XXL | 3XL | 4XL | 5XL |
|---|---|---|---|---|---|---|---|---|---|
| Costura 1–2: las dos orillas miden igual | ✓ -0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Costura 2–3: las dos orillas miden igual | ✓ 0.0 | ✓ 0.0 | ✓ -0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ -0.0 | ✓ 0.0 | ✓ 0.0 |
| Costura 3–4: las dos orillas miden igual | ✓ 0.0 | ✓ 0.0 | ✓ -0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Costura 4–5: las dos orillas miden igual | ✓ -0.0 | ✓ 0.0 | ✓ -0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ -0.0 |
| Costura 5–6: las dos orillas miden igual | ✓ -0.0 | ✓ 0.0 | ✓ -0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ -0.0 |
| Costura 6–7: las dos orillas miden igual | ✓ 0.0 | ✓ 0.0 | ✓ -0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ -0.0 | ✓ 0.0 | ✓ 0.0 |
| Costura 7–8: las dos orillas miden igual | ✓ 0.0 | ✓ 0.0 | ✓ -0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ -0.0 | ✓ 0.0 | ✓ 0.0 |
| Contorno del corsé en borde superior = objetivo (±0,3 cm) | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ -0.0 | ✓ 0.0 | ✓ 0.0 | ✓ -0.0 | ✓ 0.0 |
| Contorno del corsé en bajo busto = objetivo (±0,3 cm) | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ -0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Contorno del corsé en cintura = objetivo (±0,3 cm) | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Contorno del corsé en borde inferior = objetivo (±0,3 cm) | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ -0.0 | ✓ 0.0 | ✓ 0.0 |
| Reducción de cintura frente al cuerpo (cm, con la abertura de espalda) | ✓ 8.0 | ✓ 8.0 | ✓ 8.0 | ✓ 8.0 | ✓ 8.0 | ✓ 8.0 | ✓ 8.0 | ✓ 8.0 | ✓ 8.0 |
| Ancho mínimo de panel en la cintura (mín, 3,0 cm para la varilla y su canal) | ✓ 3.19 | ✓ 3.56 | ✓ 3.94 | ✓ 4.31 | ✓ 4.81 | ✓ 5.31 | ✓ 5.81 | ✓ 6.31 | ✓ 6.81 |
| Varilla más corta (mín. 8 cm) | ✓ 23.62 | ✓ 23.61 | ✓ 23.61 | ✓ 23.41 | ✓ 23.01 | ✓ 22.41 | ✓ 21.71 | ✓ 21.01 | ✓ 20.31 |
| Contorno válido: Panel 1 · Centro delantero | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Panel 2 · Frente | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Panel 3 · Busto lateral | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Panel 4 · Costado delantero | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Panel 5 · Costado trasero | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Panel 6 · Espalda lateral | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Panel 7 · Espalda | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Panel 8 · Centro espalda | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Panel de modestia (va bajo los cordones) | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Cinta de cintura (estabiliza la reducción) | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |

## Hojas por talla

| Talla | Carta | A4 |
|---|---|---|
| XS | 8 | 8 |
| S | 8 | 9 |
| M | 8 | 9 |
| L | 9 | 10 |
| XL | 10 | 11 |
| XXL | 11 | 11 |
| 3XL | 11 | 11 |
| 4XL | 11 | 10 |
| 5XL | 11 | 10 |
