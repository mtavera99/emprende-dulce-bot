# Validación · Blusa Básica con Pinzas de Busto · Tallas grandes (MP26-02-BLU01-G)

| Control | 3XL | 4XL | 5XL |
|---|---|---|---|
| Hombro delantero = hombro espalda | ✓ -0.0 | ✓ 0.0 | ✓ 0.0 |
| Costado delantero (menos pinza) = costado espalda | ✓ -0.0 | ✓ 0.0 | ✓ 0.0 |
| Embebido de copa (copa menos sisa), 0,5 a 1,2 | ✓ 0.8 | ✓ 0.8 | ✓ 0.8 |
| Bajo manga delantero = trasero | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Vista delantera = escote delantero | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Vista de espalda = escote de espalda | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Holgura de busto (6 a 10) | ✓ 8.0 | ✓ 8.0 | ✓ 8.0 |
| Holgura de cadera (mín. 4) | ✓ 8.0 | ✓ 8.0 | ✓ 8.0 |
| Paso de cabeza: escote + abertura de gota menos cabeza (mín. 2) | ✓ 7.2 | ✓ 7.92 | ✓ 8.64 |
| Ruedo con dobladillo de 3,0 cm en espejo | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Contorno válido: Delantero | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Espalda | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Vista de escote delantera | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Vista de escote espalda | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Manga corta | ✓ 0 | ✓ 0 | ✓ 0 |

## Hojas por talla

| Talla | Carta | A4 |
|---|---|---|
| 3XL | 18 | 20 |
| 4XL | 22 | 20 |
| 5XL | 23 | 23 |
