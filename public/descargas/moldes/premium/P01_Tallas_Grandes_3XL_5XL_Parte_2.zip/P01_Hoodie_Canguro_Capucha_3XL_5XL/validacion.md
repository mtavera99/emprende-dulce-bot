# Validación · Hoodie Canguro con Capucha (Unisex) · Tallas grandes (MP26-05-DEP04-G)

| Control | 3XL | 4XL | 5XL |
|---|---|---|---|
| Hombro delantero = hombro espalda | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 |
| Costado delantero = costado espalda | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Copa de manga menos sisa (punto: 0 a 0,5) | ✓ 0.2 | ✓ 0.2 | ✓ 0.2 |
| Bajo manga delantero = trasero | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Ancho de bíceps: excede brazo + 12 (mín. 0) | ✓ 0.13 | ✓ 0.18 | ✓ 0.06 |
| Escote de capucha (2 laterales + panel) = escote del cuerpo | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Costura de coronilla: lateral = panel central | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Abertura de cara menos cabeza (8 a 18) | ✓ 11.6 | ✓ 11.4 | ✓ 11.2 |
| Alto de capucha (lateral + medio panel) menos 58 % de la cabeza (mín. 0) | ✓ 0.92 | ✓ 0.78 | ✓ 0.64 |
| Boca de bolsillo canguro cabe la mano (mín. 15) | ✓ 9.21 | ✓ 10.7 | ✓ 12.19 |
| Pretina = 85 % del ruedo | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Puño = 75 % del ruedo de manga | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Paso de cadera: pretina estirada al 140 % menos cadera (mín. 0) | ✓ 47.74 | ✓ 49.26 | ✓ 50.78 |
| Contorno válido: Delantero | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Espalda | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Manga de hombro caído | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Bolsillo canguro | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Capucha lateral | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Panel central de capucha | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Puño de manga en rib | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Pretina de ruedo en rib | ✓ 0 | ✓ 0 | ✓ 0 |

## Hojas por talla

| Talla | Carta | A4 |
|---|---|---|
| 3XL | 36 | 36 |
| 4XL | 43 | 38 |
| 5XL | 46 | 47 |
