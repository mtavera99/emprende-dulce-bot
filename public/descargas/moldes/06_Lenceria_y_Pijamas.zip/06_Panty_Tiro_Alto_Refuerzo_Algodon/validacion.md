# Validación · Panty Tiro Alto con Refuerzo de Algodón (MP26-06-LEN02)

| Control | XS | S | M | L | XL | XXL |
|---|---|---|---|---|---|---|
| Costado delantero = costado trasero | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Refuerzo = unión del delantero (al doblez × 2) | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Refuerzo = unión del trasero (al doblez × 2) | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Compresión de cadera (objetivo −12 %, ±0,5 %) | ✓ -12.0 | ✓ -12.0 | ✓ -12.0 | ✓ -12.0 | ✓ -12.0 | ✓ -12.0 |
| Elástico de cintura respecto a la cintura de la prenda (88 a 95 %) | ✓ 92.6 | ✓ 92.63 | ✓ 92.66 | ✓ 92.68 | ✓ 92.63 | ✓ 92.59 |
| Paso de cadera: elástico de cintura estirado al 160 % menos cadera (mín. 0) | ✓ 0.08 | ✓ 2.56 | ✓ 5.04 | ✓ 7.52 | ✓ 10.72 | ✓ 13.92 |
| Largo de tiro respecto al cuerpo (2 × tiro + 8): −5 a −15 % | ✓ -5.17 | ✓ -5.36 | ✓ -5.53 | ✓ -5.87 | ✓ -6.19 | ✓ -6.48 |
| Ancho mínimo del refuerzo (mín. 5,5) | ✓ 5.7 | ✓ 5.7 | ✓ 5.7 | ✓ 5.7 | ✓ 5.7 | ✓ 5.7 |
| Contorno válido: Delantero | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Trasero de cobertura completa | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Refuerzo higiénico | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |

## Hojas por talla

| Talla | Carta | A4 |
|---|---|---|
| XS | 4 | 4 |
| S | 5 | 4 |
| M | 5 | 4 |
| L | 5 | 5 |
| XL | 6 | 5 |
| XXL | 6 | 6 |
