# Validación · Bustier Strapless a la Cintura 5 Paneles (MP26-P03-COR04)

| Control | XS | S | M | L | XL | XXL | 3XL | 4XL | 5XL |
|---|---|---|---|---|---|---|---|---|---|
| Costura 1–2: las dos orillas miden igual | ✓ -0.0 | ✓ -0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ -0.0 | ✓ 0.0 | ✓ 0.0 |
| Costura 2–3: las dos orillas miden igual | ✓ -0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ -0.0 | ✓ 0.0 | ✓ -0.0 |
| Costura 3–4: las dos orillas miden igual | ✓ 0.0 | ✓ 0.0 | ✓ -0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ -0.0 | ✓ 0.0 | ✓ -0.0 |
| Costura 4–5: las dos orillas miden igual | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ -0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ -0.0 | ✓ 0.0 |
| Contorno del corsé en borde superior = objetivo (±0,3 cm) | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ -0.0 | ✓ 0.0 | ✓ 0.0 |
| Contorno del corsé en busto = objetivo (±0,3 cm) | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Contorno del corsé en bajo busto = objetivo (±0,3 cm) | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Contorno del corsé en cintura = objetivo (±0,3 cm) | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Contorno del corsé en borde inferior = objetivo (±0,3 cm) | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ -0.0 |
| Reducción de cintura frente al cuerpo (cm) | ✓ 2.0 | ✓ 2.0 | ✓ 2.0 | ✓ 2.0 | ✓ 2.0 | ✓ 2.0 | ✓ 2.0 | ✓ 2.0 | ✓ 2.0 |
| Ancho mínimo de panel en la cintura (mín, 3,5 cm para la varilla y su canal) | ✓ 6.2 | ✓ 6.8 | ✓ 7.4 | ✓ 8.0 | ✓ 8.8 | ✓ 9.6 | ✓ 10.4 | ✓ 11.2 | ✓ 12.0 |
| Varilla más corta (mín. 8 cm) | ✓ 14.78 | ✓ 15.28 | ✓ 15.68 | ✓ 15.78 | ✓ 15.57 | ✓ 15.17 | ✓ 14.67 | ✓ 14.17 | ✓ 13.67 |
| Contorno válido: Panel 1 · Centro delantero | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Panel 2 · Frente | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Panel 3 · Costado | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Panel 4 · Espalda | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Panel 5 · Centro espalda | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Cinta de cintura (estabiliza la reducción) | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |

## Hojas por talla

| Talla | Carta | A4 |
|---|---|---|
| XS | 6 | 6 |
| S | 6 | 6 |
| M | 7 | 6 |
| L | 7 | 7 |
| XL | 7 | 7 |
| XXL | 8 | 6 |
| 3XL | 8 | 6 |
| 4XL | 8 | 8 |
| 5XL | 8 | 8 |
