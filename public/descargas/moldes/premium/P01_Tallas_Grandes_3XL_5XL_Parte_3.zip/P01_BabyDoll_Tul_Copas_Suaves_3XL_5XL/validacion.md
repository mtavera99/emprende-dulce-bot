# Validación · BabyDoll de Tul con Copas Suaves · Tallas grandes (MP26-06-LEN03-G)

| Control | 3XL | 4XL | 5XL |
|---|---|---|---|
| Costura de copa: central = lateral | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Base de copas = banda delantera menos puente central | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Costado: banda delantera = banda de espalda | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Costado de falda: delantera = trasera | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Fruncido de falda delantera sobre la banda (1,55 a 1,65) | ✓ 1.6 | ✓ 1.6 | ✓ 1.6 |
| Fruncido de falda trasera sobre la banda (1,55 a 1,65) | ✓ 1.6 | ✓ 1.6 | ✓ 1.6 |
| Compresión bajo busto (objetivo −10 %, ±0,5 %) | ✓ -10.0 | ✓ -10.0 | ✓ -10.0 |
| Paso por busto sin cierre: banda estirada al 140 % menos busto (mín. 0) | ✓ 9.56 | ✓ 10.38 | ✓ 11.2 |
| Vuelo: ruedo respecto a (cadera + 30) (mín. 1,0) | ✓ 1.19 | ✓ 1.21 | ✓ 1.23 |
| Contorno válido: Copa central | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Copa lateral | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Banda delantera bajo copa | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Banda de espalda | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Falda delantera de tul | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Falda trasera de tul | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Tirante en tubo al bies | ✓ 0 | ✓ 0 | ✓ 0 |

## Hojas por talla

| Talla | Carta | A4 |
|---|---|---|
| 3XL | 15 | 15 |
| 4XL | 15 | 16 |
| 5XL | 16 | 19 |
