# Validación · Falda Media Campana con Vuelo (MP26-04-FAL03)

| Control | XS | S | M | L | XL | XXL |
|---|---|---|---|---|---|---|
| Costado delantero = costado trasero | ✓ 0.0 | ✓ -0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Pretina delantera = cintura delantera | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Pretina trasera = cintura trasera | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Cintura del medio círculo = π × radio | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 |
| Holgura de cintura (1,5 a 2,5) | ✓ 2.0 | ✓ 2.0 | ✓ 2.0 | ✓ 2.0 | ✓ 2.0 | ✓ 2.0 |
| Vuelo: ruedo respecto a la cadera (mín. 1,8) | ✓ 2.62 | ✓ 2.55 | ✓ 2.49 | ✓ 2.44 | ✓ 2.35 | ✓ 2.28 |
| Margen de cremallera invisible | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Holgura en la línea de cadera (mín. 4) | ✓ 35.69 | ✓ 37.26 | ✓ 38.83 | ✓ 40.4 | ✓ 41.97 | ✓ 43.54 |
| Contorno válido: Delantero media campana | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Trasero media campana | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Pretina delantera | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Pretina trasera | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |

## Hojas por talla

| Talla | Carta | A4 |
|---|---|---|
| XS | 18 | 18 |
| S | 18 | 21 |
| M | 21 | 21 |
| L | 24 | 21 |
| XL | 24 | 21 |
| XXL | 24 | 24 |
