# Validación · Body de Bebé con Hombro Americano (MP26-07-INF04)

| Control | 0-3 | 3-6 | 6-12 | 12-18 | 18-24 |
|---|---|---|---|---|---|
| Costado delantero = costado espalda | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Copa de manga menos sisa sin solapas (punto: 0 a 0,5) | ✓ 0.2 | ✓ 0.2 | ✓ 0.2 | ✓ 0.2 | ✓ 0.2 |
| Bajo manga delantero = trasero | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Paso de cabeza: escote abierto estirado al 115 % menos cabeza (mín. 0) | ✓ 25.15 | ✓ 26.63 | ✓ 26.96 | ✓ 27.47 | ✓ 27.52 |
| Ribete de escote delantero = 90 % del canto | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Ribete de pierna = 85 % de la abertura | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Tapeta delantera = lengüeta delantera | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Tapeta trasera = lengüeta trasera | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Holgura de pañal: cadera menos (pecho + 10) (mín. 0) | ✓ 2.0 | ✓ 2.0 | ✓ 2.0 | ✓ 2.0 | ✓ 2.0 |
| Tronco de la prenda menos tronco del bebé (2 a 4) | ✓ 2.5 | ✓ 2.5 | ✓ 2.5 | ✓ 2.5 | ✓ 2.5 |
| Lengüeta trasera más ancha que la delantera (cubre el pañal, mín. 1) | ✓ 2.1 | ✓ 2.22 | ✓ 2.34 | ✓ 2.42 | ✓ 2.5 |
| Contorno válido: Delantero | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Espalda | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Manga corta | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Ribete de escote y solapa · delantero | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Ribete de escote y solapa · espalda | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Ribete de pierna | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Ribete de manga | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Tapeta de broches delantera | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Tapeta de broches trasera | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |

## Hojas por talla

| Talla | Carta | A4 |
|---|---|---|
| 0-3 | 8 | 8 |
| 3-6 | 8 | 8 |
| 6-12 | 10 | 8 |
| 12-18 | 10 | 9 |
| 18-24 | 10 | 10 |
