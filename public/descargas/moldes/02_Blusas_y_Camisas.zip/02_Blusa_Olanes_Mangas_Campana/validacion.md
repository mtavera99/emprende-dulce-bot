# Validación · Blusa con Olanes y Mangas Campana (MP26-02-BLU03)

| Control | XS | S | M | L | XL | XXL |
|---|---|---|---|---|---|---|
| Hombro delantero = hombro espalda | ✓ 0.0 | ✓ -0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Costado delantero (menos pinza) = costado espalda | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ -0.0 | ✓ -0.0 | ✓ 0.0 |
| Embebido de copa (copa menos sisa), 0,5 a 1,2 | ✓ 0.8 | ✓ 0.8 | ✓ 0.8 | ✓ 0.8 | ✓ 0.8 | ✓ 0.8 |
| Bajo manga delantero = trasero | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Olán delantero = ruedo delantero | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 |
| Olán de espalda = ruedo de espalda | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 |
| Costado del olán: delantero = espalda | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Campana: ruedo de manga respecto al bíceps (mín. 1,5) | ✓ 1.8 | ✓ 1.83 | ✓ 1.85 | ✓ 1.87 | ✓ 1.88 | ✓ 1.9 |
| Paso de cabeza: escote + gota menos cabeza (mín. 2) | ✓ 3.71 | ✓ 4.02 | ✓ 4.33 | ✓ 5.04 | ✓ 5.76 | ✓ 6.48 |
| Vistas: escote delantero | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Contorno válido: Delantero | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Espalda | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Vista de escote delantera | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Vista de escote espalda | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Manga campana 3/4 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Olán circular delantero | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Olán circular espalda | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |

## Hojas por talla

| Talla | Carta | A4 |
|---|---|---|
| XS | 21 | 20 |
| S | 23 | 22 |
| M | 24 | 23 |
| L | 25 | 25 |
| XL | 26 | 27 |
| XXL | 29 | 28 |
