# Validación · Capa Impermeable para Perro (MP26-08-PER02)

| Control | S | M | L | XL |
|---|---|---|---|---|
| Tramo del cuello sobre el lomo = escote del lomo | ✓ 0.0 | ✓ -0.0 | ✓ 0.0 | ✓ -0.0 |
| Cuello cerrado = cuello del perro + 3 | ✓ 0.0 | ✓ -0.0 | ✓ 0.0 | ✓ 0.0 |
| Faja ventral: largo = luz + anclaje + cruce | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Faja ventral alcanza a cerrar (luz cubierta por la faja, mín. 0) | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Faja pectoral alcanza a cerrar (mín. 0) | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Solapa cubre la ranura del arnés (sobra por lado, mín. 1,5) | ✓ 2.0 | ✓ 2.0 | ✓ 2.0 | ✓ 2.0 |
| Corte de cola: holgura sobre la base de la cola (mín. 0,8) | ✓ 1.0 | ✓ 1.0 | ✓ 1.0 | ✓ 1.0 |
| Lomo cubre el pecho (fracción del contorno, 0,75 a 0,95) | ✓ 0.92 | ✓ 0.91 | ✓ 0.9 | ✓ 0.9 |
| Lomo cubre la cintura (fracción, 0,60 a 0,80; el resto lo cierra la faja) | ✓ 0.72 | ✓ 0.72 | ✓ 0.72 | ✓ 0.72 |
| Contorno válido: Lomo envolvente con corte de cola | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Cuello chimenea impermeable | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Solapa de acceso al arnés | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Faja pectoral con velcro | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Faja ventral con cruce de velcro | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |

## Hojas por talla

| Talla | Carta | A4 |
|---|---|---|
| S | 6 | 6 |
| M | 8 | 8 |
| L | 8 | 8 |
| XL | 13 | 11 |
