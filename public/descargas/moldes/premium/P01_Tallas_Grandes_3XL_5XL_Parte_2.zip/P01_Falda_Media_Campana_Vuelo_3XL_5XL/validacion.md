# Validación · Falda Media Campana con Vuelo · Tallas grandes (MP26-04-FAL03-G)

| Control | 3XL | 4XL | 5XL |
|---|---|---|---|
| Costado delantero = costado trasero | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Pretina delantera = cintura delantera | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Pretina trasera = cintura trasera | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Cintura del medio círculo = π × radio | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 |
| Holgura de cintura (1,5 a 2,5) | ✓ 2.0 | ✓ 2.0 | ✓ 2.0 |
| Vuelo: ruedo respecto a la cadera (mín. 1,8) | ✓ 2.21 | ✓ 2.15 | ✓ 2.1 |
| Margen de cremallera invisible | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Holgura en la línea de cadera (mín. 4) | ✓ 45.12 | ✓ 46.69 | ✓ 48.26 |
| Contorno válido: Delantero media campana | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Trasero media campana | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Pretina delantera | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Pretina trasera | ✓ 0 | ✓ 0 | ✓ 0 |

## Hojas por talla

| Talla | Carta | A4 |
|---|---|---|
| 3XL | 24 | 24 |
| 4XL | 28 | 24 |
| 5XL | 28 | 24 |
