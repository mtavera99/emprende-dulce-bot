# Validación · Capri Deportiva (MP26-P02-DEP03)

| Control | XS | S | M | L | XL | XXL | 3XL | 4XL | 5XL |
|---|---|---|---|---|---|---|---|---|---|
| Costado delantero = costado trasero | ✓ 0.0 | ✓ -0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ -0.0 | ✓ 0.0 |
| Entrepierna delantera = trasera (desde el refuerzo) | ✓ -0.0 | ✓ 0.0 | ✓ -0.0 | ✓ 0.0 | ✓ -0.0 | ✓ -0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Refuerzo: lado delantero = corte del delantero | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Refuerzo: lado trasero = corte del trasero | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Pretina delantera = cintura delantera | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 |
| Pretina trasera = cintura trasera | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 |
| Compresión en cadera (objetivo −15 %, ±0,5 %) | ✓ -15.0 | ✓ -15.0 | ✓ -15.0 | ✓ -15.0 | ✓ -15.0 | ✓ -15.0 | ✓ -15.0 | ✓ -15.0 | ✓ -15.0 |
| Compresión del ruedo contra el cuerpo a esa altura (-20 % a -10 %) | ✓ -12.48 | ✓ -11.93 | ✓ -11.45 | ✓ -11.12 | ✓ -11.07 | ✓ -11.02 | ✓ -10.98 | ✓ -10.94 | ✓ -10.9 |
| Paso de cadera: estiramiento que necesita la cintura para pasar la cadera (máx. 60 %) | ✓ 58.86 | ✓ 55.76 | ✓ 54.26 | ✓ 51.39 | ✓ 48.2 | ✓ 45.86 | ✓ 43.92 | ✓ 42.23 | ✓ 40.76 |
| Compresión del canto superior de pretina (−5 % a −15 %) | ✓ -11.48 | ✓ -11.95 | ✓ -13.0 | ✓ -13.0 | ✓ -13.03 | ✓ -13.25 | ✓ -13.47 | ✓ -13.66 | ✓ -13.82 |
| Paso del pie por el ruedo estirado al 160 % (mín. 0) | ✓ 12.07 | ✓ 13.06 | ✓ 14.04 | ✓ 14.97 | ✓ 15.78 | ✓ 16.59 | ✓ 17.4 | ✓ 18.21 | ✓ 19.02 |
| Tiro con refuerzo frente a tiro sin refuerzo (−2,0 a 0) | ✓ -1.0 | ✓ -1.0 | ✓ -1.0 | ✓ -1.0 | ✓ -1.0 | ✓ -1.0 | ✓ -1.0 | ✓ -1.0 | ✓ -1.0 |
| Entrepierna después del refuerzo (mín. 4 cm) | ✓ 48.35 | ✓ 48.38 | ✓ 48.45 | ✓ 48.14 | ✓ 47.23 | ✓ 46.34 | ✓ 45.47 | ✓ 44.62 | ✓ 43.78 |
| Contorno válido: Delantero | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Trasero | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Refuerzo anatómico en rombo (gusset) | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Pretina delantera de compresión | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Pretina trasera de compresión | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |

## Hojas por talla

| Talla | Carta | A4 |
|---|---|---|
| XS | 12 | 12 |
| S | 12 | 12 |
| M | 13 | 14 |
| L | 16 | 14 |
| XL | 16 | 15 |
| XXL | 16 | 16 |
| 3XL | 17 | 16 |
| 4XL | 17 | 15 |
| 5XL | 17 | 17 |
