# Validación · Panty Tiro Alto con Refuerzo de Algodón · Tallas grandes (MP26-06-LEN02-G)

| Control | 3XL | 4XL | 5XL |
|---|---|---|---|
| Costado delantero = costado trasero | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Refuerzo = unión del delantero (al doblez × 2) | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Refuerzo = unión del trasero (al doblez × 2) | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Compresión de cadera (objetivo −12 %, ±0,5 %) | ✓ -12.0 | ✓ -12.0 | ✓ -12.0 |
| Elástico de cintura respecto a la cintura de la prenda (88 a 95 %) | ✓ 92.65 | ✓ 92.61 | ✓ 92.67 |
| Paso de cadera: elástico de cintura estirado al 160 % menos cadera (mín. 0) | ✓ 17.28 | ✓ 20.48 | ✓ 23.84 |
| Largo de tiro respecto al cuerpo (2 × tiro + 8): −5 a −15 % | ✓ -6.76 | ✓ -7.03 | ✓ -7.28 |
| Ancho mínimo del refuerzo (mín. 5,5) | ✓ 5.7 | ✓ 5.7 | ✓ 5.7 |
| Contorno válido: Delantero | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Trasero de cobertura completa | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Refuerzo higiénico | ✓ 0 | ✓ 0 | ✓ 0 |

## Hojas por talla

| Talla | Carta | A4 |
|---|---|---|
| 3XL | 6 | 6 |
| 4XL | 6 | 6 |
| 5XL | 7 | 7 |
