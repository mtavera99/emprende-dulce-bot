# Validación · Conjunto Niño: Bermuda + Camisa Cuello Mao (MP26-07-INF03)

| Control | 2 | 4 | 6 | 8 | 10 |
|---|---|---|---|---|---|
| Hombro delantero = hombro espalda | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ -0.0 | ✓ -0.0 |
| Costado delantero = costado espalda | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Embebido de copa (copa menos sisa), 0,3 a 1,0 | ✓ 0.6 | ✓ 0.6 | ✓ 0.6 | ✓ 0.6 | ✓ 0.6 |
| Bajo manga delantero = trasero | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Cuello mao (centro esp. a centro del.) = escote | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ -0.0 | ✓ 0.0 |
| Holgura de pecho (10 a 14) | ✓ 12.0 | ✓ 12.0 | ✓ 12.0 | ✓ 12.0 | ✓ 12.0 |
| Ruedo con dobladillo de 3,0 cm en espejo | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Escote de la camisa menos cuello (1,5 a 5) | ✓ 2.69 | ✓ 2.55 | ✓ 2.37 | ✓ 2.19 | ✓ 1.97 |
| Bermuda: Costado delantero (con costadillo) = costado trasero | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 | ✓ 0.0 | ✓ -0.0 |
| Bermuda: Entrepierna delantera = trasera | ✓ 0.0 | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 | ✓ 0.0 |
| Bermuda: Boca de bolsillo cabe la mano (mín. 11) | ✓ 1.38 | ✓ 1.39 | ✓ 1.4 | ✓ 1.41 | ✓ 1.41 |
| Bermuda: Pretina = cintura del pantalón (delantero + trasero) | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Bermuda: Paso de cadera: cintura de la prenda menos cadera (mín. 2) | ✓ 5.27 | ✓ 5.25 | ✓ 5.24 | ✓ 5.22 | ✓ 5.21 |
| Bermuda: Elástico respecto a la cintura del cuerpo (88 a 95 %) | ✓ 91.96 | ✓ 92.08 | ✓ 92.0 | ✓ 91.93 | ✓ 92.0 |
| Bermuda: Fruncido de la pretina sobre el elástico (1,2 a 1,7 veces) | ✓ 1.29 | ✓ 1.32 | ✓ 1.37 | ✓ 1.42 | ✓ 1.45 |
| Bermuda: Holgura de cadera (mín, 9,9) | ✓ 10.0 | ✓ 10.0 | ✓ 10.0 | ✓ 10.0 | ✓ 10.0 |
| Bermuda: Ruedo con dobladillo de 3,0 cm en espejo | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Contorno válido: Camisa · delantero con cartera | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Camisa · espalda | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Camisa · manga corta | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Cuello mao | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Bermuda · delantero | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Bermuda · trasero | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Costadillo de bolsillo | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Fondo de bolsillo (forro) | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Pretina con túnel para elástico | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |

## Hojas por talla

| Talla | Carta | A4 |
|---|---|---|
| 2 | 15 | 14 |
| 4 | 17 | 16 |
| 6 | 18 | 18 |
| 8 | 19 | 19 |
| 10 | 22 | 21 |
