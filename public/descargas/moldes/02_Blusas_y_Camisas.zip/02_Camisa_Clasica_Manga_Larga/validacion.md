# Validación · Camisa Clásica Manga Larga (MP26-02-CAM01)

| Control | XS | S | M | L | XL | XXL |
|---|---|---|---|---|---|---|
| Unión delantero = canesú (franja de hombro) | ✓ 0.0 | ✓ 0.0 | ✓ -0.0 | ✓ -0.0 | ✓ 0.0 | ✓ 0.0 |
| Espalda (menos pliegue) = canesú | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Costado delantero (menos pinza) = costado espalda | ✓ 0.0 | ✓ 0.0 | ✓ -0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Embebido de copa (copa menos sisa), 0,3 a 1,0 | ✓ 0.7 | ✓ 0.7 | ✓ 0.7 | ✓ 0.7 | ✓ 0.7 | ✓ 0.7 |
| Bajo manga delantero = trasero | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Ruedo de manga (menos pliegues) = puño | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Pie de cuello (centro esp. a centro del.) = escote | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Cuello = borde superior del pie | ✓ 0.0 | ✓ 0.0 | ✓ -0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Sardineta: abertura = bajo-sardineta | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Ancho de bíceps: excede brazo + 7 (mín. 0) | ✓ 2.6 | ✓ 1.85 | ✓ 1.27 | ✓ 0.87 | ✓ 0.84 | ✓ 0.84 |
| Holgura de cadera de la prenda (mín. 6) | ✓ 13.0 | ✓ 13.0 | ✓ 13.0 | ✓ 13.0 | ✓ 13.0 | ✓ 13.0 |
| Contorno válido: Delantero con cartera incorporada | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Espalda con pliegue de holgura | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Canesú doble | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Manga sastre con abertura | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Sardineta superior (con punta) | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Bajo-sardineta (vivo de abertura) | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Puño anatómico redondeado | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Pie de cuello (tirilla anatómica) | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Cuello con puntas | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |

## Hojas por talla

| Talla | Carta | A4 |
|---|---|---|
| XS | 22 | 20 |
| S | 22 | 20 |
| M | 22 | 20 |
| L | 22 | 21 |
| XL | 25 | 25 |
| XXL | 27 | 27 |
