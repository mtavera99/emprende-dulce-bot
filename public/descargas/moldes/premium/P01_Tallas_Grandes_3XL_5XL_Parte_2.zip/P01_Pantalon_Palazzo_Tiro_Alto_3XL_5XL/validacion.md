# Validación · Pantalón Palazzo Tiro Alto · Tallas grandes (MP26-03-PAN01-G)

| Control | 3XL | 4XL | 5XL |
|---|---|---|---|
| Costado delantero (con costadillo) = costado trasero | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Entrepierna delantera = trasera | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Boca de bolsillo cabe la mano (mín. 14) | ✓ 4.19 | ✓ 4.18 | ✓ 4.17 |
| Pretina delantera = cintura delantera (menos pinza) | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 |
| Pretina trasera = cintura trasera (menos pinzas) | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 |
| Cintura delantera montada (costadillo + delantero − pinza) = trazado | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Cintura trasera (menos pinzas) = trazado | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Holgura sobre la línea de cintura de la prenda (1,5 a 2,5) | ✓ 2.01 | ✓ 2.01 | ✓ 2.01 |
| Holgura de cadera (mín, 5,9) | ✓ 6.0 | ✓ 6.0 | ✓ 6.0 |
| Medio ancho de ruedo = objetivo | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Margen de cremallera invisible (centro trasero) | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Ruedo con dobladillo de 3,0 cm | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Contorno válido: Delantero palazzo | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Trasero palazzo | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Costadillo de bolsillo | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Fondo de bolsillo (forro) | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Pretina anatómica delantera | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Pretina anatómica trasera | ✓ 0 | ✓ 0 | ✓ 0 |

## Hojas por talla

| Talla | Carta | A4 |
|---|---|---|
| 3XL | 31 | 29 |
| 4XL | 31 | 31 |
| 5XL | 32 | 32 |
