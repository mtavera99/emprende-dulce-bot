# Validación · Hoodie Canguro con Capucha (Unisex) (MP26-05-DEP04)

| Control | XS | S | M | L | XL | XXL |
|---|---|---|---|---|---|---|
| Hombro delantero = hombro espalda | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 |
| Costado delantero = costado espalda | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Copa de manga menos sisa (punto: 0 a 0,5) | ✓ 0.2 | ✓ 0.2 | ✓ 0.2 | ✓ 0.2 | ✓ 0.2 | ✓ 0.2 |
| Bajo manga delantero = trasero | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Ancho de bíceps: excede brazo + 12 (mín. 0) | ✓ 1.96 | ✓ 0.92 | ✓ 0.25 | ✓ 0.19 | ✓ 0.11 | ✓ 0.18 |
| Escote de capucha (2 laterales + panel) = escote del cuerpo | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Costura de coronilla: lateral = panel central | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Abertura de cara menos cabeza (8 a 18) | ✓ 14.0 | ✓ 13.6 | ✓ 13.2 | ✓ 12.8 | ✓ 12.4 | ✓ 12.0 |
| Alto de capucha (lateral + medio panel) menos 58 % de la cabeza (mín. 0) | ✓ 2.6 | ✓ 2.32 | ✓ 2.04 | ✓ 1.76 | ✓ 1.48 | ✓ 1.2 |
| Boca de bolsillo canguro cabe la mano (mín. 15) | ✓ 1.4 | ✓ 2.52 | ✓ 3.63 | ✓ 4.75 | ✓ 6.23 | ✓ 7.72 |
| Pretina = 85 % del ruedo | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Puño = 75 % del ruedo de manga | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Paso de cadera: pretina estirada al 140 % menos cadera (mín. 0) | ✓ 35.76 | ✓ 36.9 | ✓ 38.04 | ✓ 39.18 | ✓ 42.7 | ✓ 46.22 |
| Contorno válido: Delantero | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Espalda | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Manga de hombro caído | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Bolsillo canguro | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Capucha lateral | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Panel central de capucha | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Puño de manga en rib | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Pretina de ruedo en rib | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |

## Hojas por talla

| Talla | Carta | A4 |
|---|---|---|
| XS | 30 | 27 |
| S | 29 | 29 |
| M | 30 | 30 |
| L | 31 | 32 |
| XL | 32 | 33 |
| XXL | 35 | 35 |
