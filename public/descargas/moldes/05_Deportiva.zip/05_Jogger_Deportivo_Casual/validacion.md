# Validación · Jogger Deportivo Casual (MP26-05-DEP03)

| Control | XS | S | M | L | XL | XXL |
|---|---|---|---|---|---|---|
| Costado delantero (con costadillo) = costado trasero | ✓ 0.0 | ✓ 0.0 | ✓ -0.0 | ✓ 0.0 | ✓ -0.0 | ✓ 0.0 |
| Entrepierna delantera = trasera | ✓ 0.0 | ✓ -0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ -0.0 |
| Boca de bolsillo cabe la mano (mín. 14) | ✓ 2.53 | ✓ 2.53 | ✓ 2.54 | ✓ 2.54 | ✓ 2.55 | ✓ 2.55 |
| Pretina = cintura del pantalón (delantero + trasero) | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Paso de cadera: cintura de la prenda menos cadera (mín. 2) | ✓ 4.29 | ✓ 4.28 | ✓ 4.27 | ✓ 4.26 | ✓ 4.26 | ✓ 4.26 |
| Elástico respecto a la cintura del cuerpo (88 a 95 %) | ✓ 92.03 | ✓ 92.0 | ✓ 91.97 | ✓ 91.95 | ✓ 92.0 | ✓ 92.04 |
| Fruncido de la pretina sobre el elástico (1,2 a 1,7 veces) | ✓ 1.6 | ✓ 1.56 | ✓ 1.52 | ✓ 1.49 | ✓ 1.45 | ✓ 1.42 |
| Holgura de cadera (mín, 9,9) | ✓ 10.0 | ✓ 10.0 | ✓ 10.0 | ✓ 10.0 | ✓ 10.0 | ✓ 10.0 |
| Puño de tobillo = 75 % de la abertura de la pierna | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Paso de talón: puño estirado al 160 % menos (tobillo + 10) (mín. 0) | ✓ 4.8 | ✓ 6.39 | ✓ 7.98 | ✓ 9.56 | ✓ 11.35 | ✓ 13.13 |
| Contorno válido: Delantero con bolsillo inclinado | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Trasero | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Costadillo de bolsillo | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Fondo de bolsillo (forro) | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Pretina con túnel para elástico y cordón | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Puño de tobillo en rib | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |

## Hojas por talla

| Talla | Carta | A4 |
|---|---|---|
| XS | 22 | 23 |
| S | 25 | 25 |
| M | 26 | 26 |
| L | 27 | 27 |
| XL | 27 | 28 |
| XXL | 28 | 30 |
