# Validación · Vestido de Fiesta Escote en V Cruzado (MP26-01-VES04)

| Control | XS | S | M | L | XL | XXL |
|---|---|---|---|---|---|---|
| Hombro delantero = hombro espalda | ✓ -0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Costado delantero (menos pinza) = costado espalda | ✓ 0.0 | ✓ -0.0 | ✓ 0.0 | ✓ -0.0 | ✓ -0.0 | ✓ 0.0 |
| Cintura delantera (menos pliegues y cruce) = falda delantera | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Cintura espalda (menos pinza) = falda trasera | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Costado de falda delantera = trasera | ✓ -0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Holgura de busto (3 a 6) | ✓ 4.0 | ✓ 4.0 | ✓ 4.0 | ✓ 4.0 | ✓ 4.0 | ✓ 4.0 |
| Holgura de cintura (2 a 4) | ✓ 3.0 | ✓ 3.0 | ✓ 3.0 | ✓ 3.0 | ✓ 3.0 | ✓ 3.0 |
| Escote en V: profundidad menos altura de busto (−8 a 0) | ✓ -1.45 | ✓ -1.45 | ✓ -1.44 | ✓ -1.37 | ✓ -1.46 | ✓ -1.65 |
| Margen de cremallera invisible | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Contorno válido: Corpiño delantero cruzado | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Corpiño espalda | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Falda delantera de medio círculo | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Falda trasera de medio círculo | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |

## Hojas por talla

| Talla | Carta | A4 |
|---|---|---|
| XS | 29 | 28 |
| S | 29 | 28 |
| M | 29 | 29 |
| L | 29 | 32 |
| XL | 32 | 32 |
| XXL | 35 | 32 |
