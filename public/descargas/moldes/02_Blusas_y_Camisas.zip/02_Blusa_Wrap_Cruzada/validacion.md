# Validación · Blusa Wrap Cruzada (MP26-02-BLU02)

| Control | XS | S | M | L | XL | XXL |
|---|---|---|---|---|---|---|
| Hombro delantero = hombro espalda | ✓ -0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Costado delantero (menos pinza) = costado espalda | ✓ 0.0 | ✓ -0.0 | ✓ 0.0 | ✓ -0.0 | ✓ 0.0 | ✓ -0.0 |
| Embebido de copa (copa menos sisa), 0,5 a 1,2 | ✓ 0.8 | ✓ 0.8 | ✓ 0.8 | ✓ 0.8 | ✓ 0.8 | ✓ 0.8 |
| Bajo manga delantero = trasero | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Cinturilla delantera (sin lazo) = cintura delantera menos pliegues | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Cinturilla espalda = cintura de espalda menos pinza | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Bies = escote en V + escote de espalda | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Holgura de cintura cerrada (2 a 5) | ✓ 3.0 | ✓ 3.0 | ✓ 3.0 | ✓ 3.0 | ✓ 3.0 | ✓ 3.0 |
| Cruce del delantero respecto al cuarto de cintura (0,6 a 0,9) | ✓ 0.75 | ✓ 0.75 | ✓ 0.75 | ✓ 0.75 | ✓ 0.75 | ✓ 0.75 |
| Holgura de busto (6 a 10) | ✓ 8.0 | ✓ 8.0 | ✓ 8.0 | ✓ 8.0 | ✓ 8.0 | ✓ 8.0 |
| Contorno válido: Delantero cruzado | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Espalda | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Manga corta | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Cinturilla delantera con lazo | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Cinturilla espalda | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Bies de escote continuo | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |

## Hojas por talla

| Talla | Carta | A4 |
|---|---|---|
| XS | 17 | 18 |
| S | 18 | 18 |
| M | 18 | 20 |
| L | 17 | 21 |
| XL | 20 | 20 |
| XXL | 21 | 19 |
