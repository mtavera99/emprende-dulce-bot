# Validación · Pantalón Recto de Vestir (MP26-03-PAN02)

| Control | XS | S | M | L | XL | XXL |
|---|---|---|---|---|---|---|
| Costado delantero (con costadillo) = costado trasero | ✓ -0.0 | ✓ 0.0 | ✓ 0.0 | ✓ -0.0 | ✓ 0.0 | ✓ 0.0 |
| Entrepierna delantera = trasera | ✓ 0.0 | ✓ -0.0 | ✓ 0.0 | ✓ -0.0 | ✓ -0.0 | ✓ 0.0 |
| Boca de bolsillo cabe la mano (mín. 14) | ✓ 2.97 | ✓ 2.97 | ✓ 2.97 | ✓ 2.97 | ✓ 2.97 | ✓ 2.97 |
| Pretina = cintura del pantalón + cruce | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Cintura delantera montada (costadillo + delantero − pinza) = trazado | ✓ 0.01 | ✓ 0.01 | ✓ 0.01 | ✓ 0.01 | ✓ 0.0 | ✓ 0.0 |
| Cintura trasera (menos pinzas) = trazado | ✓ 0.0 | ✓ -0.0 | ✓ 0.0 | ✓ -0.0 | ✓ -0.0 | ✓ 0.0 |
| Holgura sobre la línea de cintura de la prenda (1,5 a 2,5) | ✓ 2.01 | ✓ 2.01 | ✓ 2.01 | ✓ 2.01 | ✓ 2.01 | ✓ 2.01 |
| Holgura de cadera (mín, 3,9) | ✓ 4.0 | ✓ 4.0 | ✓ 4.0 | ✓ 4.0 | ✓ 4.0 | ✓ 4.0 |
| Cruce de cremallera (margen de bragueta) | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Aletilla más larga que la cremallera (mín. 1,5) | ✓ 2.0 | ✓ 2.0 | ✓ 2.0 | ✓ 2.0 | ✓ 2.0 | ✓ 2.0 |
| Ruedo con dobladillo de 3,0 cm | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Contorno válido: Delantero con bragueta | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Trasero con bolsillo ribeteado | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Costadillo de bolsillo | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Fondo de bolsillo (forro) | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Aletilla (vista de bragueta) | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Pie de bragueta (bajo cremallera) | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Ribete de bolsillo trasero | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Espejo de bolsillo trasero | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Fondo de bolsillo trasero (forro) | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Pretina sastre | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Tira de pasadores (6 de 9 cm) | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |

## Hojas por talla

| Talla | Carta | A4 |
|---|---|---|
| XS | 26 | 26 |
| S | 29 | 28 |
| M | 31 | 32 |
| L | 32 | 31 |
| XL | 36 | 31 |
| XXL | 36 | 33 |
