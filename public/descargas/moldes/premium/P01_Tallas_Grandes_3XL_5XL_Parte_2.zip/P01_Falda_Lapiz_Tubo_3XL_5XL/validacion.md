# Validación · Falda Lápiz de Tubo Formal · Tallas grandes (MP26-04-FAL01-G)

| Control | 3XL | 4XL | 5XL |
|---|---|---|---|
| Costado delantero = costado trasero | ✓ -0.01 | ✓ -0.01 | ✓ -0.01 |
| Cintura delantera (menos pinza) = trazado | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Cintura trasera (menos pinza) = trazado | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Pretina delantera = cintura delantera | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 |
| Pretina trasera = cintura trasera | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 |
| Holgura de cadera (mín. 3,9) | ✓ 4.0 | ✓ 4.0 | ✓ 4.0 |
| Pinzas de entalle (2 delanteras + 2 traseras) | ✓ 0 | ✓ 0 | ✓ 0 |
| Margen de cremallera invisible | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Paso al caminar: ruedo + abertura abierta frente a cadera (mín. 0) | ✓ 20.0 | ✓ 20.0 | ✓ 20.0 |
| Ruedo con dobladillo de 3,0 cm | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Contorno válido: Delantero | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Trasero con abertura | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Pretina anatómica delantera | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Pretina anatómica trasera | ✓ 0 | ✓ 0 | ✓ 0 |

## Hojas por talla

| Talla | Carta | A4 |
|---|---|---|
| 3XL | 17 | 15 |
| 4XL | 18 | 15 |
| 5XL | 19 | 15 |
