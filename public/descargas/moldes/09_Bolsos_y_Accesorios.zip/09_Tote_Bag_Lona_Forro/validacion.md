# Validación · Bolso Tote Bag en Lona con Forro (MP26-09-BOL01)

| Control | Mini | Mediano | Grande |
|---|---|---|---|
| Fondo armado: recorte (lado + base) = fondo | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Ancho de base entre recortes = ancho del bolso | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Boca: exterior = forro | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Forro más bajo que el exterior para que no abolse (0,3 a 0,8) | ✓ 0.5 | ✓ 0.5 | ✓ 0.5 |
| Bolsillo interior: espacio libre a los lados (mín. 6) | ✓ 12.0 | ✓ 15.2 | ✓ 18.4 |
| Caída del asa para llevar al hombro (mín. 22) | ✓ 24.0 | ✓ 28.0 | ✓ 30.0 |
| Capacidad (mín. 5 litros) | ✓ 6.5 | ✓ 15.5 | ✓ 25.8 |
| Contorno válido: Exterior (delantero y espalda) | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Forro (delantero y espalda) | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Bolsillo interior doble | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Asa en lona (doblada en 4) | ✓ 0 | ✓ 0 | ✓ 0 |

## Hojas por talla

| Talla | Carta | A4 |
|---|---|---|
| Mini | 14 | 12 |
| Mediano | 18 | 18 |
| Grande | 22 | 22 |
