# Validación · Short Ciclista Pretina Alta tipo Faja (MP26-P04-DEP08)

| Control | XS | S | M | L | XL | XXL | 3XL | 4XL | 5XL |
|---|---|---|---|---|---|---|---|---|---|
| Costado delantero = costado trasero | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ -0.0 | ✓ 0.0 | ✓ -0.0 | ✓ 0.0 | ✓ 0.0 | ✓ -0.0 |
| Entrepierna delantera = trasera (desde el refuerzo) | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 | ✓ 0.0 | ✓ -0.0 |
| Refuerzo: lado delantero = corte del delantero | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Refuerzo: lado trasero = corte del trasero | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Pretina delantera = cintura delantera | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 |
| Pretina trasera = cintura trasera | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 |
| Compresión en cadera (objetivo −15 %, ±0,5 %) | ✓ -15.0 | ✓ -15.0 | ✓ -15.0 | ✓ -15.0 | ✓ -15.0 | ✓ -15.0 | ✓ -15.0 | ✓ -15.0 | ✓ -15.0 |
| Compresión del ruedo contra el cuerpo a esa altura (-20 % a -10 %) | ✓ -17.93 | ✓ -18.37 | ✓ -18.71 | ✓ -18.82 | ✓ -18.73 | ✓ -18.6 | ✓ -18.47 | ✓ -18.32 | ✓ -18.16 |
| Paso de cadera: estiramiento que necesita la cintura para pasar la cadera (máx. 60 %) | ✓ 58.86 | ✓ 55.76 | ✓ 54.26 | ✓ 51.39 | ✓ 48.2 | ✓ 45.86 | ✓ 43.92 | ✓ 42.23 | ✓ 40.76 |
| Compresión del canto superior de pretina (−5 % a −15 %) | ✓ -11.48 | ✓ -11.95 | ✓ -13.0 | ✓ -13.0 | ✓ -13.03 | ✓ -13.25 | ✓ -13.47 | ✓ -13.66 | ✓ -13.82 |
| Paso del pie por el ruedo estirado al 160 % (mín. 0) | ✓ 13.7 | ✓ 14.1 | ✓ 14.54 | ✓ 15.14 | ✓ 16.15 | ✓ 17.19 | ✓ 18.26 | ✓ 19.36 | ✓ 20.48 |
| Tiro con refuerzo frente a tiro sin refuerzo (−2,0 a 0) | ✓ -1.0 | ✓ -1.0 | ✓ -1.0 | ✓ -1.0 | ✓ -1.0 | ✓ -1.0 | ✓ -1.0 | ✓ -1.0 | ✓ -1.0 |
| Entrepierna después del refuerzo (mín. 4 cm) | ✓ 13.8 | ✓ 13.58 | ✓ 13.4 | ✓ 13.09 | ✓ 12.41 | ✓ 11.74 | ✓ 11.1 | ✓ 10.47 | ✓ 9.85 |
| Contorno válido: Delantero | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Trasero | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Refuerzo anatómico en rombo (gusset) | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Pretina delantera de compresión | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Pretina trasera de compresión | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |

## Hojas por talla

| Talla | Carta | A4 |
|---|---|---|
| XS | 9 | 9 |
| S | 9 | 9 |
| M | 9 | 10 |
| L | 10 | 10 |
| XL | 10 | 11 |
| XXL | 11 | 11 |
| 3XL | 11 | 11 |
| 4XL | 12 | 12 |
| 5XL | 12 | 13 |
