# Validación · Corsé Underbust 6 Paneles con Busk (MP26-P03-COR02)

| Control | XS | S | M | L | XL | XXL | 3XL | 4XL | 5XL |
|---|---|---|---|---|---|---|---|---|---|
| Costura 1–2: las dos orillas miden igual | ✓ 0.0 | ✓ 0.0 | ✓ -0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ -0.0 | ✓ 0.0 |
| Costura 2–3: las dos orillas miden igual | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ -0.0 | ✓ 0.0 | ✓ -0.0 | ✓ -0.0 | ✓ 0.0 | ✓ 0.0 |
| Costura 3–4: las dos orillas miden igual | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ -0.0 | ✓ 0.0 | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 |
| Costura 4–5: las dos orillas miden igual | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ -0.0 | ✓ 0.0 | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 |
| Costura 5–6: las dos orillas miden igual | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ -0.0 | ✓ 0.0 | ✓ -0.0 | ✓ -0.0 | ✓ 0.0 | ✓ 0.0 |
| Contorno del corsé en bajo busto = objetivo (±0,3 cm) | ✓ 0.0 | ✓ -0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ -0.0 | ✓ 0.0 |
| Contorno del corsé en cintura = objetivo (±0,3 cm) | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 | ✓ 0.0 | ✓ 0.0 | ✓ -0.0 | ✓ -0.0 | ✓ 0.0 |
| Contorno del corsé en borde inferior = objetivo (±0,3 cm) | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 | ✓ 0.0 | ✓ -0.0 | ✓ 0.0 | ✓ 0.0 | ✓ -0.0 | ✓ 0.0 |
| Reducción de cintura frente al cuerpo (cm, con la abertura de espalda) | ✓ 6.0 | ✓ 6.0 | ✓ 6.0 | ✓ 6.0 | ✓ 6.0 | ✓ 6.0 | ✓ 6.0 | ✓ 6.0 | ✓ 6.0 |
| Ancho mínimo de panel en la cintura (mín, 3,5 cm para la varilla y su canal) | ✓ 4.42 | ✓ 4.92 | ✓ 5.42 | ✓ 5.92 | ✓ 6.58 | ✓ 7.25 | ✓ 7.92 | ✓ 8.58 | ✓ 9.25 |
| Varilla más corta (mín. 8 cm) | ✓ 18.63 | ✓ 18.63 | ✓ 18.63 | ✓ 18.42 | ✓ 18.02 | ✓ 17.42 | ✓ 16.72 | ✓ 16.02 | ✓ 15.32 |
| Contorno válido: Panel 1 · Centro delantero | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Panel 2 · Frente | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Panel 3 · Costado delantero | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Panel 4 · Costado trasero | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Panel 5 · Espalda | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Panel 6 · Centro espalda | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Panel de modestia (va bajo los cordones) | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Cinta de cintura (estabiliza la reducción) | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |

## Hojas por talla

| Talla | Carta | A4 |
|---|---|---|
| XS | 7 | 6 |
| S | 7 | 6 |
| M | 7 | 7 |
| L | 7 | 7 |
| XL | 8 | 8 |
| XXL | 8 | 7 |
| 3XL | 8 | 7 |
| 4XL | 9 | 7 |
| 5XL | 7 | 8 |
