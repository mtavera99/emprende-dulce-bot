# Validación · Blusa con Olanes y Mangas Campana · Tallas grandes (MP26-02-BLU03-G)

| Control | 3XL | 4XL | 5XL |
|---|---|---|---|
| Hombro delantero = hombro espalda | ✓ -0.0 | ✓ 0.0 | ✓ 0.0 |
| Costado delantero (menos pinza) = costado espalda | ✓ 0.0 | ✓ 0.0 | ✓ -0.0 |
| Embebido de copa (copa menos sisa), 0,5 a 1,2 | ✓ 0.8 | ✓ 0.8 | ✓ 0.8 |
| Bajo manga delantero = trasero | ✓ -0.0 | ✓ 0.0 | ✓ -0.0 |
| Olán delantero = ruedo delantero | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 |
| Olán de espalda = ruedo de espalda | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 |
| Costado del olán: delantero = espalda | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Campana: ruedo de manga respecto al bíceps (mín. 1,5) | ✓ 1.91 | ✓ 1.92 | ✓ 1.93 |
| Paso de cabeza: escote + gota menos cabeza (mín. 2) | ✓ 7.2 | ✓ 7.92 | ✓ 8.64 |
| Vistas: escote delantero | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Contorno válido: Delantero | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Espalda | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Vista de escote delantera | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Vista de escote espalda | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Manga campana 3/4 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Olán circular delantero | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Olán circular espalda | ✓ 0 | ✓ 0 | ✓ 0 |

## Hojas por talla

| Talla | Carta | A4 |
|---|---|---|
| 3XL | 32 | 29 |
| 4XL | 35 | 31 |
| 5XL | 39 | 34 |
