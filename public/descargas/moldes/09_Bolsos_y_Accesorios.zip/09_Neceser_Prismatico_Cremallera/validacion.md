# Validación · Neceser Prismático con Cremallera (MP26-09-BOL02)

| Control | Mini | Mediano | Grande |
|---|---|---|---|
| Perímetro de tapa = lateral del cuerpo + 2 extremos de banda + cremallera | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Banda de cremallera = largo del cuerpo | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Lateral del cuerpo = 2 laterales de tapa + base de tapa (aristas en los piquetes) | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Cremallera más larga que el neceser (4 cm para los jaladores) | ✓ 4.0 | ✓ 4.0 | ✓ 4.0 |
| Contorno válido: Cuerpo (frente + base + espalda) | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Banda de cremallera | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Tapa lateral | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Jalador de cremallera (tira doblada en 4) | ✓ 0 | ✓ 0 | ✓ 0 |

## Hojas por talla

| Talla | Carta | A4 |
|---|---|---|
| Mini | 4 | 4 |
| Mediano | 5 | 6 |
| Grande | 6 | 6 |
