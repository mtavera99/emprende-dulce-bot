# Validación · Delantal Barista con Tirantes en X (MP26-10-UNI02)

| Control | S | M | L |
|---|---|---|---|
| Bolsillo de cadera = ancho marcado en el cuerpo | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Margen libre del bolsillo al costado (mín. 5) | ✓ 6.0 | ✓ 6.0 | ✓ 6.0 |
| Ruedo con dobladillo de 3,0 cm en espejo | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Sisa curva con dobladillo de 1,0 cm | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Tirante cruzado alcanza la cintura por la espalda (mín. 0) | ✓ 16.0 | ✓ 20.0 | ✓ 24.0 |
| Proporción pechera / cintura (0,35 a 0,45) | ✓ 0.4 | ✓ 0.39 | ✓ 0.39 |
| Contorno válido: Cuerpo del delantal con pechera | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Bolsillo doble de cadera | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Bolsillo de pechera | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Tirante cruzado (doblado en 4) | ✓ 0 | ✓ 0 | ✓ 0 |

## Hojas por talla

| Talla | Carta | A4 |
|---|---|---|
| S | 25 | 18 |
| M | 27 | 19 |
| L | 21 | 28 |
