# Validación · Legging Deportiva Tiro Alto · Tallas grandes (MP26-05-DEP01-G)

| Control | 3XL | 4XL | 5XL |
|---|---|---|---|
| Costado delantero = costado trasero | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Entrepierna delantera = trasera (desde el refuerzo) | ✓ 0.0 | ✓ 0.0 | ✓ -0.0 |
| Refuerzo: lado delantero = corte del delantero | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Refuerzo: lado trasero = corte del trasero | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Pretina delantera = cintura delantera | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 |
| Pretina trasera = cintura trasera | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 |
| Compresión en cadera (objetivo −15 %, ±0,5 %) | ✓ -15.0 | ✓ -15.0 | ✓ -15.0 |
| Compresión en muslo (objetivo −15 %, ±0,5 %) | ✓ -15.0 | ✓ -15.0 | ✓ -15.0 |
| Compresión en rodilla (objetivo −15 %, ±0,5 %) | ✓ -15.0 | ✓ -15.0 | ✓ -15.0 |
| Compresión en pantorrilla (objetivo −15 %, ±0,5 %) | ✓ -15.0 | ✓ -15.0 | ✓ -15.0 |
| Compresión en tobillo (objetivo −5 %, ±0,5 %) | ✓ -5.0 | ✓ -5.0 | ✓ -5.0 |
| Paso de cadera: estiramiento que necesita la cintura para pasar la cadera (máx. 60 %) | ✓ 43.92 | ✓ 42.23 | ✓ 40.76 |
| Compresión del canto superior de pretina (−5 % a −15 %) | ✓ -13.47 | ✓ -13.66 | ✓ -13.82 |
| Paso de talón: ruedo estirado al 160 % menos (tobillo + 10) (mín. 0) | ✓ 2.74 | ✓ 3.26 | ✓ 3.78 |
| Tiro con refuerzo frente a tiro sin refuerzo (−2,0 a 0) | ✓ -1.0 | ✓ -1.0 | ✓ -1.0 |
| Ruedo con dobladillo de 3,0 cm en espejo | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Contorno válido: Delantero | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Trasero | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Refuerzo anatómico en rombo (gusset) | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Pretina delantera de compresión | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Pretina trasera de compresión | ✓ 0 | ✓ 0 | ✓ 0 |

## Hojas por talla

| Talla | Carta | A4 |
|---|---|---|
| 3XL | 20 | 20 |
| 4XL | 20 | 20 |
| 5XL | 20 | 21 |
