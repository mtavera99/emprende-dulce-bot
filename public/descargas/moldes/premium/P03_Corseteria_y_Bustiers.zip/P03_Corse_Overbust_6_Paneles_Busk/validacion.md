# Validación · Corsé Overbust 6 Paneles con Busk (MP26-P03-COR01)

| Control | XS | S | M | L | XL | XXL | 3XL | 4XL | 5XL |
|---|---|---|---|---|---|---|---|---|---|
| Costura 1–2: las dos orillas miden igual | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ -0.0 | ✓ -0.0 | ✓ 0.0 | ✓ -0.0 | ✓ -0.0 | ✓ 0.0 |
| Costura 2–3: las dos orillas miden igual | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 | ✓ 0.0 | ✓ -0.0 | ✓ 0.0 |
| Costura 3–4: las dos orillas miden igual | ✓ 0.0 | ✓ -0.0 | ✓ -0.0 | ✓ 0.0 | ✓ 0.0 | ✓ -0.0 | ✓ 0.0 | ✓ -0.0 | ✓ 0.0 |
| Costura 4–5: las dos orillas miden igual | ✓ -0.0 | ✓ 0.0 | ✓ 0.0 | ✓ -0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ -0.0 | ✓ 0.0 |
| Costura 5–6: las dos orillas miden igual | ✓ 0.0 | ✓ 0.0 | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Contorno del corsé en borde superior = objetivo (±0,3 cm) | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ -0.0 | ✓ 0.0 | ✓ 0.0 | ✓ -0.0 | ✓ 0.0 |
| Contorno del corsé en busto = objetivo (±0,3 cm) | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ -0.0 | ✓ 0.0 |
| Contorno del corsé en bajo busto = objetivo (±0,3 cm) | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ -0.0 | ✓ -0.0 | ✓ 0.0 |
| Contorno del corsé en cintura = objetivo (±0,3 cm) | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 | ✓ 0.0 | ✓ 0.0 | ✓ -0.0 | ✓ -0.0 | ✓ 0.0 |
| Contorno del corsé en borde inferior = objetivo (±0,3 cm) | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 | ✓ 0.0 | ✓ -0.0 | ✓ 0.0 | ✓ 0.0 | ✓ -0.0 | ✓ 0.0 |
| Reducción de cintura frente al cuerpo (cm, con la abertura de espalda) | ✓ 6.0 | ✓ 6.0 | ✓ 6.0 | ✓ 6.0 | ✓ 6.0 | ✓ 6.0 | ✓ 6.0 | ✓ 6.0 | ✓ 6.0 |
| Ancho mínimo de panel en la cintura (mín, 3,5 cm para la varilla y su canal) | ✓ 4.42 | ✓ 4.92 | ✓ 5.42 | ✓ 5.92 | ✓ 6.58 | ✓ 7.25 | ✓ 7.92 | ✓ 8.58 | ✓ 9.25 |
| Varilla más corta (mín. 8 cm) | ✓ 25.55 | ✓ 26.05 | ✓ 26.45 | ✓ 26.54 | ✓ 26.34 | ✓ 25.94 | ✓ 25.44 | ✓ 24.94 | ✓ 24.44 |
| Contorno válido: Panel 1 · Centro delantero | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Panel 2 · Frente | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Panel 3 · Costado delantero | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Panel 4 · Costado trasero | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Panel 5 · Espalda | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Panel 6 · Centro espalda | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Panel de modestia (va bajo los cordones) | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Cinta de cintura (estabiliza la reducción) | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |

## Hojas por talla

| Talla | Carta | A4 |
|---|---|---|
| XS | 8 | 9 |
| S | 9 | 9 |
| M | 9 | 9 |
| L | 9 | 10 |
| XL | 10 | 10 |
| XXL | 11 | 11 |
| 3XL | 11 | 11 |
| 4XL | 11 | 11 |
| 5XL | 11 | 12 |
