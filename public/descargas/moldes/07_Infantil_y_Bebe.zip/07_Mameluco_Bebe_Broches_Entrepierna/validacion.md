# Validación · Mameluco Enterito de Bebé con Broches (MP26-07-INF01)

| Control | 0-3 | 3-6 | 6-12 | 12-18 | 18-24 |
|---|---|---|---|---|---|
| Costado delantero = costado espalda | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Hombro delantero = hombro espalda | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 | ✓ 0.0 | ✓ 0.0 |
| Abertura: entrepierna delantera = trasera | ✓ 0.0 | ✓ -0.0 | ✓ -0.0 | ✓ 0.0 | ✓ -0.0 |
| Abertura: tiro delantero = tiro trasero | ✓ -0.0 | ✓ 0.0 | ✓ -0.0 | ✓ 0.0 | ✓ 0.0 |
| Copa de manga menos sisa (punto: 0 a 0,5) | ✓ 0.2 | ✓ 0.2 | ✓ 0.2 | ✓ 0.2 | ✓ 0.2 |
| Bajo manga delantero = trasero | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Tapeta delantera = tiro + entrepierna del delantero | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Tapeta trasera = 2 × (tiro + entrepierna de la espalda) | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Tobillera = 80 % de la abertura de tobillo | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Puño = 80 % del ruedo de manga | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Holgura de pañal: cadera de la prenda menos (pecho + 12) (mín. 0) | ✓ 4.0 | ✓ 4.0 | ✓ 4.0 | ✓ 4.0 | ✓ 4.0 |
| Tronco de la prenda menos tronco del bebé (2 a 4, pañal) | ✓ 2.5 | ✓ 2.5 | ✓ 2.5 | ✓ 2.5 | ✓ 2.5 |
| Ancho de manga menos brazo (mín. 5,9) | ✓ 6.87 | ✓ 6.87 | ✓ 7.14 | ✓ 7.54 | ✓ 7.95 |
| Contorno válido: Delantero con cartera de broches | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Espalda | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Manga | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Tapeta de broches delantera | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Tapeta de broches trasera | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Ribete de escote | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Puño de manga | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Tobillera | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |

## Hojas por talla

| Talla | Carta | A4 |
|---|---|---|
| 0-3 | 12 | 11 |
| 3-6 | 12 | 12 |
| 6-12 | 13 | 13 |
| 12-18 | 18 | 16 |
| 18-24 | 19 | 19 |
