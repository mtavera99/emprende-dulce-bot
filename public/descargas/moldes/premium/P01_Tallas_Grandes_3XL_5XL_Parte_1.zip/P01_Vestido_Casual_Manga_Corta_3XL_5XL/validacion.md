# Validación · Vestido Casual Manga Corta · Tallas grandes (MP26-01-VES03-G)

| Control | 3XL | 4XL | 5XL |
|---|---|---|---|
| Hombro delantero = hombro espalda | ✓ -0.0 | ✓ -0.0 | ✓ 0.0 |
| Costado delantero (menos pinza) = costado espalda | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Vista delantera = escote delantero | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Vista de espalda = escote de espalda | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Embebido de copa (copa menos sisa), 0,5 a 1,2 | ✓ 0.8 | ✓ 0.8 | ✓ 0.8 |
| Bajo manga delantero = trasero | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Holgura de busto (5 a 8) | ✓ 6.0 | ✓ 6.0 | ✓ 6.0 |
| Holgura de cadera (mín. 6) | ✓ 10.0 | ✓ 10.0 | ✓ 10.0 |
| Vuelo: ruedo menos cadera (mín. 20) | ✓ 31.99 | ✓ 32.0 | ✓ 32.01 |
| Margen de cremallera invisible | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Ruedo con dobladillo de 3,0 cm en espejo | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Contorno válido: Delantero en A | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Espalda en A | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Vista de escote delantera | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Vista de escote espalda | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Manga corta | ✓ 0 | ✓ 0 | ✓ 0 |

## Hojas por talla

| Talla | Carta | A4 |
|---|---|---|
| 3XL | 29 | 30 |
| 4XL | 32 | 30 |
| 5XL | 32 | 31 |
