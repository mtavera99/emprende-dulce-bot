# Validación · Top Deportivo Racerback · Tallas grandes (MP26-05-DEP02-G)

| Control | 3XL | 4XL | 5XL |
|---|---|---|---|
| Hombro delantero = hombro espalda | ✓ -0.0 | ✓ 0.0 | ✓ -0.0 |
| Costado delantero = costado espalda | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Banda = borde inferior (delantero + espalda) | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Forro: borde inferior = delantero + cruce | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Compresión en busto (objetivo −8 %, ±0,5 %) | ✓ -8.0 | ✓ -8.0 | ✓ -8.0 |
| Compresión en bajo busto (objetivo −8 %, ±0,5 %) | ✓ -7.95 | ✓ -7.96 | ✓ -7.96 |
| Elástico de banda respecto al bajo busto (83 a 88 %) | ✓ 85.0 | ✓ 84.96 | ✓ 85.0 |
| Paso por busto y hombros: elástico estirado al 150 % menos busto (mín. 0) | ✓ 11.15 | ✓ 12.0 | ✓ 13.0 |
| Ancho mínimo del tirante delantero (mín. 3,5) | ✓ 5.68 | ✓ 6.0 | ✓ 6.32 |
| Ancho mínimo del tirante de espalda (mín. 3,5) | ✓ 5.55 | ✓ 5.85 | ✓ 6.15 |
| Espalda nadadora: ancho central respecto al ancho de espalda (15 a 30 %, omóplatos libres) | ✓ 22.0 | ✓ 22.0 | ✓ 22.0 |
| Paso de cabeza: escote estirado al 130 % menos cabeza (mín. 0) | ✓ 29.99 | ✓ 33.22 | ✓ 36.46 |
| Abertura de copas (largo del cruce, mín. 12) | ✓ 21.1 | ✓ 21.45 | ✓ 21.8 |
| Contorno válido: Delantero | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Forro delantero con abertura para copas | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Espalda nadadora | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Banda bajo busto (túnel del elástico) | ✓ 0 | ✓ 0 | ✓ 0 |

## Hojas por talla

| Talla | Carta | A4 |
|---|---|---|
| 3XL | 13 | 13 |
| 4XL | 13 | 13 |
| 5XL | 15 | 14 |
