# Validación · Bralette de Encaje con Copas Triangulares · Tallas grandes (MP26-06-LEN01-G)

| Control | 3XL | 4XL | 5XL |
|---|---|---|---|
| Costura de copa: central = lateral | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Base de copas cosida (sin pinza) = banda delantera menos puente central | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Costado: banda delantera = banda de espalda | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Compresión bajo busto con corchete en posición central (objetivo −10 %, ±0,5 %) | ✓ -10.0 | ✓ -10.0 | ✓ -10.0 |
| Proyección de copa respecto a (busto − bajo busto) (0,18 a 0,35) | ✓ 0.33 | ✓ 0.34 | ✓ 0.35 |
| Elástico afelpado respecto al borde de la banda (95 a 99 %) | ✓ 96.96 | ✓ 96.95 | ✓ 97.04 |
| Banda de espalda: largo útil (mín. 8) | ✓ 22.35 | ✓ 23.93 | ✓ 25.5 |
| Contorno válido: Copa central | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Copa lateral | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Banda delantera bajo copa | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Banda de espalda | ✓ 0 | ✓ 0 | ✓ 0 |

## Hojas por talla

| Talla | Carta | A4 |
|---|---|---|
| 3XL | 5 | 5 |
| 4XL | 5 | 5 |
| 5XL | 5 | 5 |
