# Validación · Vestido de Fiesta Escote en V Cruzado · Tallas grandes (MP26-01-VES04-G)

| Control | 3XL | 4XL | 5XL |
|---|---|---|---|
| Hombro delantero = hombro espalda | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Costado delantero (menos pinza) = costado espalda | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Cintura delantera (menos pliegues y cruce) = falda delantera | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Cintura espalda (menos pinza) = falda trasera | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Costado de falda delantera = trasera | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Holgura de busto (3 a 6) | ✓ 4.0 | ✓ 4.0 | ✓ 4.0 |
| Holgura de cintura (2 a 4) | ✓ 3.0 | ✓ 3.0 | ✓ 3.0 |
| Escote en V: profundidad menos altura de busto (−8 a 0) | ✓ -1.89 | ✓ -2.12 | ✓ -2.35 |
| Margen de cremallera invisible | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Contorno válido: Corpiño delantero cruzado | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Corpiño espalda | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Falda delantera de medio círculo | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Falda trasera de medio círculo | ✓ 0 | ✓ 0 | ✓ 0 |

## Hojas por talla

| Talla | Carta | A4 |
|---|---|---|
| 3XL | 38 | 34 |
| 4XL | 39 | 38 |
| 5XL | 43 | 40 |
