# Validación · Blusa Básica con Pinzas de Busto (MP26-02-BLU01)

| Control | XS | S | M | L | XL | XXL |
|---|---|---|---|---|---|---|
| Hombro delantero = hombro espalda | ✓ 0.0 | ✓ -0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Costado delantero (menos pinza) = costado espalda | ✓ 0.0 | ✓ 0.0 | ✓ -0.0 | ✓ 0.0 | ✓ 0.0 | ✓ -0.0 |
| Embebido de copa (copa menos sisa), 0,5 a 1,2 | ✓ 0.8 | ✓ 0.8 | ✓ 0.8 | ✓ 0.8 | ✓ 0.8 | ✓ 0.8 |
| Bajo manga delantero = trasero | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Vista delantera = escote delantero | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Vista de espalda = escote de espalda | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Holgura de busto (6 a 10) | ✓ 8.0 | ✓ 8.0 | ✓ 8.0 | ✓ 8.0 | ✓ 8.0 | ✓ 8.0 |
| Holgura de cadera (mín. 4) | ✓ 8.0 | ✓ 8.0 | ✓ 8.0 | ✓ 8.0 | ✓ 8.0 | ✓ 8.0 |
| Paso de cabeza: escote + abertura de gota menos cabeza (mín. 2) | ✓ 3.71 | ✓ 4.02 | ✓ 4.33 | ✓ 5.04 | ✓ 5.76 | ✓ 6.48 |
| Ruedo con dobladillo de 3,0 cm en espejo | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Contorno válido: Delantero | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Espalda | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Vista de escote delantera | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Vista de escote espalda | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Manga corta | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |

## Hojas por talla

| Talla | Carta | A4 |
|---|---|---|
| XS | 13 | 13 |
| S | 14 | 15 |
| M | 16 | 16 |
| L | 16 | 16 |
| XL | 18 | 16 |
| XXL | 19 | 16 |
