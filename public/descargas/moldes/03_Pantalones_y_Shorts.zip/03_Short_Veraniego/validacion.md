# Validación · Short Veraniego con Bolsillos (MP26-03-PAN03)

| Control | XS | S | M | L | XL | XXL |
|---|---|---|---|---|---|---|
| Costado delantero (con costadillo) = costado trasero | ✓ 0.0 | ✓ 0.0 | ✓ -0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Entrepierna delantera = trasera | ✓ 0.0 | ✓ -0.0 | ✓ -0.0 | ✓ 0.0 | ✓ -0.0 | ✓ 0.0 |
| Boca de bolsillo cabe la mano (mín. 14) | ✓ 1.07 | ✓ 1.06 | ✓ 1.06 | ✓ 1.05 | ✓ 1.04 | ✓ 1.04 |
| Pretina delantera = cintura delantera ×2 + cruce | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Pretina trasera = cintura trasera | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Cintura delantera montada (costadillo + delantero − pinza) = trazado | ✓ 0.01 | ✓ 0.01 | ✓ 0.01 | ✓ 0.01 | ✓ 0.0 | ✓ 0.0 |
| Elástico trasero recogido (menos que la pretina trasera ×2) | ✓ 9.46 | ✓ 9.45 | ✓ 9.54 | ✓ 9.53 | ✓ 9.52 | ✓ 9.51 |
| Holgura de cadera (mín, 3,9) | ✓ 4.0 | ✓ 4.0 | ✓ 4.0 | ✓ 4.0 | ✓ 4.0 | ✓ 4.0 |
| Cruce de cremallera (margen de bragueta) | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Aletilla más larga que la cremallera (mín. 1,5) | ✓ 2.0 | ✓ 2.0 | ✓ 2.0 | ✓ 2.0 | ✓ 2.0 | ✓ 2.0 |
| Ruedo con dobladillo de 3,0 cm | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Contorno válido: Delantero de short | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Trasero de short | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Costadillo de bolsillo | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Fondo de bolsillo (forro) | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Aletilla (vista de bragueta) | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Pie de bragueta (bajo cremallera) | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Pretina delantera plana | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Pretina trasera con elástico | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |

## Hojas por talla

| Talla | Carta | A4 |
|---|---|---|
| XS | 13 | 11 |
| S | 13 | 11 |
| M | 16 | 12 |
| L | 16 | 15 |
| XL | 17 | 15 |
| XXL | 17 | 16 |
