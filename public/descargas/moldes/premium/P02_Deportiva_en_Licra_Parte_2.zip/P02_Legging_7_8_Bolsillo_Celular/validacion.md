# Validación · Legging 7/8 con Bolsillo para Celular (MP26-P02-DEP06)

| Control | XS | S | M | L | XL | XXL | 3XL | 4XL | 5XL |
|---|---|---|---|---|---|---|---|---|---|
| Costado delantero = costado trasero | ✓ -0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ -0.0 | ✓ 0.0 | ✓ -0.0 | ✓ 0.0 | ✓ 0.0 |
| Entrepierna delantera = trasera (desde el refuerzo) | ✓ 0.0 | ✓ 0.0 | ✓ -0.0 | ✓ 0.0 | ✓ -0.0 | ✓ -0.0 | ✓ 0.0 | ✓ 0.0 | ✓ -0.0 |
| Refuerzo: lado delantero = corte del delantero | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Refuerzo: lado trasero = corte del trasero | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 |
| Pretina delantera = cintura delantera | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 |
| Pretina trasera = cintura trasera | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 | ✓ -0.0 |
| Compresión en cadera (objetivo −15 %, ±0,5 %) | ✓ -15.0 | ✓ -15.0 | ✓ -15.0 | ✓ -15.0 | ✓ -15.0 | ✓ -15.0 | ✓ -15.0 | ✓ -15.0 | ✓ -15.0 |
| Compresión del ruedo contra el cuerpo a esa altura (-20 % a -3 %) | ✓ -7.38 | ✓ -7.18 | ✓ -7.0 | ✓ -6.88 | ✓ -6.86 | ✓ -6.85 | ✓ -6.83 | ✓ -6.82 | ✓ -6.8 |
| Paso de cadera: estiramiento que necesita la cintura para pasar la cadera (máx. 60 %) | ✓ 58.86 | ✓ 55.76 | ✓ 54.26 | ✓ 51.39 | ✓ 48.2 | ✓ 45.86 | ✓ 43.92 | ✓ 42.23 | ✓ 40.76 |
| Compresión del canto superior de pretina (−5 % a −15 %) | ✓ -11.48 | ✓ -11.95 | ✓ -13.0 | ✓ -13.0 | ✓ -13.03 | ✓ -13.25 | ✓ -13.47 | ✓ -13.66 | ✓ -13.82 |
| Paso del pie por el ruedo estirado al 160 % (mín. 0) | ✓ 0.88 | ✓ 1.35 | ✓ 1.82 | ✓ 2.27 | ✓ 2.88 | ✓ 3.48 | ✓ 4.08 | ✓ 4.69 | ✓ 5.29 |
| Tiro con refuerzo frente a tiro sin refuerzo (−2,0 a 0) | ✓ -1.0 | ✓ -1.0 | ✓ -1.0 | ✓ -1.0 | ✓ -1.0 | ✓ -1.0 | ✓ -1.0 | ✓ -1.0 | ✓ -1.0 |
| Entrepierna después del refuerzo (mín. 4 cm) | ✓ 65.19 | ✓ 65.23 | ✓ 65.32 | ✓ 65.04 | ✓ 64.14 | ✓ 63.26 | ✓ 62.41 | ✓ 61.57 | ✓ 60.75 |
| Bolsillo: costado = tramo del costado del delantero | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ 0.0 | ✓ -0.0 | ✓ 0.0 | ✓ 0.0 | ✓ -0.0 | ✓ 0.0 |
| Bolsillo: ancho para celular (mín. 9 cm) | ✓ 13.0 | ✓ 13.0 | ✓ 13.0 | ✓ 13.0 | ✓ 13.0 | ✓ 13.0 | ✓ 13.0 | ✓ 13.0 | ✓ 13.0 |
| Bolsillo: queda por encima del ruedo (mín. 3 cm) | ✓ 65.26 | ✓ 66.26 | ✓ 67.26 | ✓ 68.26 | ✓ 68.76 | ✓ 69.26 | ✓ 69.76 | ✓ 70.26 | ✓ 70.76 |
| Contorno válido: Delantero | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Trasero | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Refuerzo anatómico en rombo (gusset) | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Bolsillo lateral para celular | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Pretina delantera de compresión | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |
| Contorno válido: Pretina trasera de compresión | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 | ✓ 0 |

## Hojas por talla

| Talla | Carta | A4 |
|---|---|---|
| XS | 16 | 14 |
| S | 16 | 14 |
| M | 16 | 18 |
| L | 19 | 18 |
| XL | 20 | 18 |
| XXL | 20 | 18 |
| 3XL | 20 | 20 |
| 4XL | 21 | 20 |
| 5XL | 22 | 22 |
